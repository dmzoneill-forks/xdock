// SPDX-License-Identifier: GPL-2.0-or-later
// SPDX-FileCopyrightText: Contributors to XDock
// -*- mode: js; js-indent-level: 4; indent-tabs-mode: nil -*-

import {
    Clutter,
    GLib,
    Gio,
    GObject,
    Meta,
    Shell,
    St,
} from './dependencies/gi.js';

import {
    AppMenu,
    AppDisplay,
    AppFavorites,
    Layout,
    Main,
    OverviewControls,
    PointerWatcher,
    SwitcherPopup,
    Workspace,
    WorkspacesView,
    WorkspaceSwitcherPopup,
} from './dependencies/shell/ui.js';

import {
    AnimationUtils,
} from './dependencies/shell/misc.js';

import {
    AppIconsDecorator,
    AppSpread,
    DockDash,
    DesktopIconsIntegration,
    FileManager1API,
    Intellihide,
    LauncherAPI,
    Locations,
    NotificationsMonitor,
    Theming,
    Utils,
} from './imports.js';

import {Extension} from './dependencies/shell/extensions/extension.js';

let CommandPalette, DockProfiles, DockTiling, MprisMonitor,
    ScreencastMonitor, SpringAnimation, PinnedCommands, VolumeControl;

async function _loadDeferredModules() {
    [CommandPalette, DockProfiles, DockTiling, MprisMonitor,
        ScreencastMonitor, SpringAnimation, PinnedCommands, VolumeControl] =
        await Promise.all([
            import('./commandPalette.js'),
            import('./dockProfiles.js'),
            import('./dockTiling.js'),
            import('./mprisMonitor.js'),
            import('./screencastMonitor.js'),
            import('./springAnimation.js'),
            import('./pinnedCommands.js'),
            import('./volumeControl.js'),
        ]);
}

// Use __ () and N__() for the extension gettext domain, and reuse
// the shell domain with the default _() and N_()
const {gettext: __} = Extension;

const {signals: Signals} = imports;

// Defaults kept as fallbacks; live values come from DockManager.settings
const DOCK_DWELL_EDGE_PX = 2;
const DOCK_DWELL_CHECK_INTERVAL = 100;
const ICON_ANIMATOR_DURATION = 3000;
const STARTUP_ANIMATION_TIME = 500;

export const State = Object.freeze({
    HIDDEN:  0,
    SHOWING: 1,
    SHOWN:   2,
    HIDING:  3,
});

const scrollAction = Object.freeze({
    DO_NOTHING: 0,
    CYCLE_WINDOWS: 1,
    SWITCH_WORKSPACE: 2,
});

const Labels = Object.freeze({
    COMMAND_PALETTE: Symbol('command-palette'),
    INITIALIZE: Symbol('initialize'),
    ISOLATION: Symbol('isolation'),
    LOCATIONS: Symbol('locations'),
    MAIN_DASH: Symbol('main-dash'),
    OLD_DASH_CHANGES: Symbol('old-dash-changes'),
    SETTINGS: Symbol('settings'),
    STARTUP_ANIMATION: Symbol('startup-animation'),
    WORKSPACE_SWITCH_SCROLL: Symbol('workspace-switch-scroll'),
});

/**
 * A simple St.Widget with one child whose allocation takes into account the
 * slide out of its child via the slide-x property ([0:1]).
 *
 * Required since I want to track the input region of this container which is
 * based on its allocation even if the child overflows the parent actor. By doing
 * this the region of the dash that is slide-out is not stealing anymore the input
 * regions making the extension usable when the primary monitor is the right one.
 *
 * The slide-x parameter can be used to directly animate the sliding. The parent
 * must have a WEST (SOUTH) anchor_point to achieve the sliding to the RIGHT (BOTTOM)
 * side.
 */
const DashSlideContainer = GObject.registerClass({
    Properties: {
        'monitor-index': GObject.ParamSpec.uint(
            'monitor-index', 'monitor-index', 'monitor-index',
            GObject.ParamFlags.READWRITE | GObject.ParamFlags.CONSTRUCT_ONLY,
            0, GLib.MAXUINT32, 0),
        'side': GObject.ParamSpec.enum(
            'side', 'side', 'side',
            GObject.ParamFlags.READWRITE | GObject.ParamFlags.CONSTRUCT_ONLY,
            St.Side, St.Side.LEFT),
        'slide-x': GObject.ParamSpec.double(
            'slide-x', 'slide-x', 'slide-x',
            GObject.ParamFlags.READWRITE | GObject.ParamFlags.CONSTRUCT,
            0, 1, 1),
        'magnification-overflow': GObject.ParamSpec.double(
            'magnification-overflow', 'magnification-overflow', 'magnification-overflow',
            GObject.ParamFlags.READWRITE,
            0, 1000, 0),
    },
}, class DashSlideContainer extends St.Bin {
    _init(params = {}) {
        super._init(params);

        this._slideoutSize = 0; // minimum size when slided out
        this.connect('notify::slide-x', () => this.queue_relayout());
        this.connect('notify::magnification-overflow', () => this.queue_relayout());

        if (this.side === St.Side.TOP && DockManager.settings.dockFixed) {
            this._signalsHandler = new Utils.GlobalSignalsHandler(this);
            this._signalsHandler.add(Main.panel, 'notify::height',
                () => this.queue_relayout());
        }
    }

    vfunc_get_paint_volume(volume) {
        if (this.magnificationOverflow > 0)
            return false;
        return super.vfunc_get_paint_volume(volume);
    }

    vfunc_allocate(box) {
        const contentBox = this.get_theme_node().get_content_box(box);

        this.set_allocation(box);

        if (!this.child)
            return;

        const availWidth = contentBox.x2 - contentBox.x1;
        let availHeight = contentBox.y2 - contentBox.y1;
        const [, , natChildWidth, natChildHeight] =
            this.child.get_preferred_size();

        const childWidth = natChildWidth;
        const childHeight = natChildHeight;

        const childBox = new Clutter.ActorBox();

        const slideoutSize = this._slideoutSize;

        if (this.side === St.Side.LEFT) {
            childBox.x1 = (this.slideX - 1) * (childWidth - slideoutSize);
            childBox.x2 = slideoutSize + this.slideX * (childWidth - slideoutSize);
            childBox.y1 = 0;
            childBox.y2 = childBox.y1 + childHeight;
        } else if ((this.side === St.Side.RIGHT) || (this.side === St.Side.BOTTOM)) {
            childBox.x1 = 0;
            childBox.x2 = childWidth;
            childBox.y1 = 0;
            childBox.y2 = childBox.y1 + childHeight;
        } else if (this.side === St.Side.TOP) {
            const monitor = Main.layoutManager.monitors[this.monitorIndex];
            let yOffset = 0;
            if (Main.panel.x === monitor.x && Main.panel.y === monitor.y &&
                DockManager.settings.dockFixed)
                yOffset = Main.panel.height;
            childBox.x1 = 0;
            childBox.x2 = childWidth;
            childBox.y1 = (this.slideX - 1) * (childHeight - slideoutSize) + yOffset;
            childBox.y2 = slideoutSize + this.slideX * (childHeight - slideoutSize) + yOffset;
            availHeight += yOffset;
        }

        this.child.allocate(childBox);

        const overflow = this.magnificationOverflow;
        if (overflow > 0) {
            this.child.remove_clip();
        } else {
            this.child.set_clip(-childBox.x1, -childBox.y1,
                -childBox.x1 + availWidth, -childBox.y1 + availHeight);
        }
    }

    /**
     * Just the child width but taking into account the slided out part
     *
     * @param forHeight
     */
    vfunc_get_preferred_width(forHeight) {
        let [minWidth, natWidth] = super.vfunc_get_preferred_width(forHeight || 0);
        if ((this.side ===  St.Side.LEFT) || (this.side === St.Side.RIGHT)) {
            minWidth = (minWidth - this._slideoutSize) * this.slideX + this._slideoutSize;
            natWidth = (natWidth - this._slideoutSize) * this.slideX + this._slideoutSize;
        }
        return [minWidth, natWidth];
    }

    /**
     * Just the child height but taking into account the slided out part
     *
     * @param forWidth
     */
    vfunc_get_preferred_height(forWidth) {
        let [minHeight, natHeight] = super.vfunc_get_preferred_height(forWidth || 0);
        if ((this.side ===  St.Side.TOP) || (this.side ===  St.Side.BOTTOM)) {
            minHeight = (minHeight - this._slideoutSize) * this.slideX + this._slideoutSize;
            natHeight = (natHeight - this._slideoutSize) * this.slideX + this._slideoutSize;

            if (this.side === St.Side.TOP && DockManager.settings.dockFixed) {
                const monitor = Main.layoutManager.monitors[this.monitorIndex];
                if (Main.panel.x === monitor.x && Main.panel.y === monitor.y) {
                    minHeight += Main.panel.height;
                    natHeight += Main.panel.height;
                }
            }
        }
        return [minHeight, natHeight];
    }
});

const DockedDash = GObject.registerClass({
    Properties: {
        'is-main': GObject.ParamSpec.boolean(
            'is-main', 'is-main', 'is-main',
            GObject.ParamFlags.READWRITE | GObject.ParamFlags.CONSTRUCT_ONLY,
            false),
        'is-secondary': GObject.ParamSpec.boolean(
            'is-secondary', 'is-secondary', 'is-secondary',
            GObject.ParamFlags.READWRITE | GObject.ParamFlags.CONSTRUCT_ONLY,
            false),
        'monitor-index': GObject.ParamSpec.uint(
            'monitor-index', 'monitor-index', 'monitor-index',
            GObject.ParamFlags.READWRITE | GObject.ParamFlags.CONSTRUCT_ONLY,
            0, GLib.MAXUINT32, 0),
    },
    Signals: {
        'showing': {},
        'hiding': {},
    },
}, class DashToDock extends St.Bin {
    vfunc_get_paint_volume(volume) {
        if (this._slider?.magnificationOverflow > 0)
            return false;
        return super.vfunc_get_paint_volume(volume);
    }

    _init(params) {
        // Determine position before super._init since we need it for style_class.
        // Secondary docks use their own position setting.
        const isSecondary = params.is_secondary || params.isSecondary || false;
        if (isSecondary)
            this._position = Utils.getSecondaryPosition();
        else
            this._position = Utils.getPosition(params?.monitorIndex ?? this.monitorIndex);

        // This is the centering actor
        super._init({
            ...params,
            name: 'dashtodockContainer',
            reactive: false,
            style_class: Theming.PositionStyleClass[this._position],
        });

        this._rtl = Clutter.get_default_text_direction() === Clutter.TextDirection.RTL;

        // Load settings
        const {settings} = DockManager;
        this._isHorizontal = (this._position === St.Side.TOP) || (this._position === St.Side.BOTTOM);

        // Temporary ignore hover events linked to autohide for whatever reason
        this._ignoreHover = false;
        this._oldIgnoreHover = null;
        // This variables are linked to the settings regardles of autohide or intellihide
        // being temporary disable. Get set by _updateVisibilityMode;
        this._autohideIsEnabled = null;
        this._intellihideIsEnabled = null;

        // This variable marks if _disableUnredirect() is called
        // to help restore the original state when intelihide is disabled.
        this._unredirectDisabled = false;

        // Create intellihide object to monitor windows overlapping
        this._intellihide = new Intellihide.Intellihide(this.monitorIndex);

        // initialize dock state - must be consistent with slide_x initial value
        // If not starting up, slide_x is 1 (visible), so state should be SHOWN
        this._dockState = Main.layoutManager._startingUp ? State.HIDDEN : State.SHOWN;

        // Put dock on the required monitor
        this._monitor = Main.layoutManager.monitors[this.monitorIndex];

        // this store size and the position where the dash is shown;
        // used by intellihide module to check window overlap.
        this._staticBox = new Clutter.ActorBox();

        // Initialize pressure barrier variables
        this._canUsePressure = false;
        this._pressureBarrier = null;
        this._barrier = null;
        this._removeBarrierTimeoutId = 0;

        // Initialize dwelling system variables
        this._dockDwelling = false;
        this._dockWatch = null;
        this._dockDwellUserTime = 0;
        this._dockDwellTimeoutId = 0;

        // Create a new dash object
        this.dash = new DockDash.DockDash(this.monitorIndex, this.isSecondary);

        if (this.isSecondary || Main.overview.isDummy || !settings.showShowAppsButton)
            this.dash.hideShowAppsButton();

        // Create the containers for sliding in and out and
        // centering, turn on track hover
        // This is the sliding actor whose allocation is to be tracked for input regions
        this._slider = new DashSlideContainer({
            monitor_index: this._monitor.index,
            side: this._position,
            slide_x: Main.layoutManager._startingUp ? 0 : 1,
            ...this._isHorizontal ? {
                x_align: Clutter.ActorAlign.CENTER,
            } : {
                y_align: Clutter.ActorAlign.CENTER,
            },
        });

        // This is the actor whose hover status us tracked for autohide
        this._box = new St.BoxLayout({
            name: 'dashtodockBox',
            reactive: true,
            track_hover: true,
        });
        // Connect global signals
        this._signalsHandler = new Utils.GlobalSignalsHandler(this);
        this._bindSettingsChanges();
        this._signalsHandler.add([
            this._box,
            'notify::hover',
            this._hoverChanged.bind(this),
        ], [
            // update when workarea changes, for instance if  other extensions modify the struts
            // (like moving th panel at the bottom)
            global.display,
            'workareas-changed',
            this._resetPosition.bind(this),
        ], [
            global.display,
            'in-fullscreen-changed',
            () => {
                this._updateBarrier();
                this._updateDashVisibility();
            },
        ], [
            // Monitor windows overlapping
            this._intellihide,
            'status-changed',
            this._updateDashVisibility.bind(this),
        ], [
            this.dash,
            'menu-opened',
            () => {
                this._onMenuOpened();
            },
        ], [
            // sync hover after a popupmenu is closed
            this.dash,
            'menu-closed',
            () => {
                this._onMenuClosed();
            },
        ], [
            this.dash,
            'notify::requires-visibility',
            () => this._updateDashVisibility(),
        ], [
            this.dash,
            'magnification-changed',
            this._onMagnificationChanged.bind(this),
        ]);

        // The signal fires during DockDash init before this handler is
        // connected. Replay it if magnification is already active.
        if (this.dash._magnificationEnabled)
            this._onMagnificationChanged(this.dash, true);


        if (!Main.overview.isDummy) {
            this._signalsHandler.add([
                Main.overview,
                'item-drag-begin',
                this._onDragStart.bind(this),
            ], [
                Main.overview,
                'item-drag-end',
                this._onDragEnd.bind(this),
            ], [
                Main.overview,
                'item-drag-cancelled',
                this._onDragEnd.bind(this),
            ], [
                Main.overview,
                'showing',
                this._onOverviewShowing.bind(this),
            ], [
                Main.overview,
                'hiding',
                this._onOverviewHiding.bind(this),
            ],
            [
                Main.overview,
                'hidden',
                this._onOverviewHidden.bind(this),
            ]);
        }

        // GNOME 50: Chrome actors with affectsStruts can have their visible
        // property set to false asynchronously during struts recalculation.
        // Watch the panelBox (on the main dock only) and restore visibility
        // immediately whenever it is hidden outside the overview.
        if (this.isMain) {
            const {panelBox} = Main.layoutManager;
            if (panelBox) {
                this._signalsHandler.add(panelBox, 'notify::visible', () => {
                    if (!panelBox.visible && !Main.overview.visibleTarget) {
                        panelBox.visible = true;
                        panelBox.show();
                    }
                });
            }
        }

        this._themeManager = new Theming.ThemeManager(this);
        this._themeInitialUpdate = true;
        this._signalsHandler.add(this._themeManager, 'updated',
            () => {
                if (this._themeInitialUpdate) {
                    this._themeInitialUpdate = false;
                    return;
                }
                this.dash.resetAppIconsDebounced();
            });

        this._signalsHandler.add(DockManager.iconTheme, 'changed',
            () => this.dash.resetAppIconsDebounced());

        // Since the actor is not a topLevel child and its parent is now not added to the Chrome,
        // the allocation change of the parent container (slide in and slideout) doesn't trigger
        // anymore an update of the input regions. Force the update manually.
        // However, skip region updates while a panel popup menu is open (Quick
        // Settings, Notifications, etc.) to avoid stealing input from those menus.
        // Use a deferred (idle) call to avoid re-entrant allocation loops that
        // can crash the compositor (e.g. when the screenshot overlay appears and
        // triggers stage view updates while the dock is mid-allocation).
        this._regionUpdateScheduled = false;
        const scheduleRegionUpdate = () => {
            if (Main.panel?.menuManager?.activeMenu)
                return;
            if (this._regionUpdateScheduled)
                return;
            this._regionUpdateScheduled = true;
            GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                this._regionUpdateScheduled = false;
                if (!this._staticBox)
                    return GLib.SOURCE_REMOVE;
                Main.layoutManager._queueUpdateRegions();
                return GLib.SOURCE_REMOVE;
            });
        };
        this._signalsHandler.add([
            this,
            'notify::allocation',
            scheduleRegionUpdate,
        ], [
            // Since Clutter has no longer ClutterAllocationFlags,
            // "allocation-changed" signal has been removed. MR !1245
            this.dash._container,
            'notify::allocation',
            this._updateStaticBox.bind(this),
        ], [
            this._slider,
            this._isHorizontal ? 'notify::x' : 'notify::y',
            this._updateStaticBox.bind(this),
        ], [
            this._slider,
            'notify::slide-x',
            scheduleRegionUpdate,
        ]);

        // Load optional features that need to be activated for one dock only
        if (this.isMain)
            this._enableExtraFeatures();
        // Load optional features that need to be activated once per dock
        this._optionalScrollWorkspaceSwitch();

        // Add dash container actor and the container to the Chrome.
        this.set_child(this._slider);
        this._slider.set_child(this._box);
        this._box.add_child(this.dash);

        // Screencast indicator: a small red dot shown when recording is active
        this._screencastIndicator = new St.Bin({
            style_class: 'screencast-indicator',
            visible: false,
            x_align: Clutter.ActorAlign.END,
            y_align: Clutter.ActorAlign.START,
            x_expand: false,
            y_expand: false,
        });
        this._box.add_child(this._screencastIndicator);

        const screencastMonitor = DockManager.getDefault()?.screencastMonitor;
        if (screencastMonitor) {
            this._signalsHandler.add(screencastMonitor, 'state-changed',
                () => this._updateScreencastIndicator());
            this._updateScreencastIndicator();
        }

        // Delay operations that require the shell to be fully loaded and with
        // user theme applied.
        if (Main.layoutManager._startingUp) {
            this._signalsHandler.addWithLabel(Labels.STARTUP_ANIMATION,
                Main.layoutManager, 'startup-complete', () => {
                    this._signalsHandler.removeWithLabel(Labels.STARTUP_ANIMATION);
                    this._trackDock();
                    this._initialize();
                });
        } else {
            this._trackDock();
            this.opacity = 0;
            this._signalsHandler.addWithLabel(Labels.INITIALIZE, global.stage,
                'after-paint', () => {
                    this._signalsHandler.removeWithLabel(Labels.INITIALIZE);
                    this._initialize();
                    this.opacity = 255;
                });
        }

        // GNOME 50: the dock itself (a Chrome actor) can be hidden by struts
        // recalculation.  Re-show it immediately unless intentionally hidden.
        this._signalsHandler.add([
            this,
            'notify::visible',
            () => {
                if (!this.visible && !Main.overview.visibleTarget &&
                    !DockManager.settings.manualhide) {
                    this.visible = true;
                    this.show();
                }
            },
        ], [
            this,
            'destroy',
            this._onDestroy.bind(this),
        ]);
    }

    get position() {
        return this._position;
    }

    get isHorizontal() {
        return this._isHorizontal;
    }

    _untrackDock() {
        Main.layoutManager.untrackChrome(this);
    }

    _trackDock() {
        if (this.get_parent())
            Main.layoutManager.removeChrome(this);

        // Secondary docks never affect struts to avoid conflicting with the primary dock
        const shouldAffectStruts = DockManager.settings.dockFixed && !this.isSecondary;
        Main.layoutManager.addChrome(this, {
            trackFullscreen: true,
            affectsStruts: shouldAffectStruts,
        });

        // Set the initial position.
        this._resetPosition();
    }

    _initialize() {
        // Create and apply height/width constraint to the dash.
        if (this._isHorizontal) {
            this.bind_property('width', this.dash, 'max-width',
                GObject.BindingFlags.SYNC_CREATE);
        } else {
            this.bind_property('height', this.dash, 'max-height',
                GObject.BindingFlags.SYNC_CREATE);
        }

        if (this._position === St.Side.RIGHT) {
            this.translation_x = -this.width;
            this._signalsHandler.add(this, 'notify::width', () =>
                (this.translation_x = -this.width));
        } else if (this._position === St.Side.BOTTOM) {
            this.translation_y = -this.height;
            this._signalsHandler.add(this, 'notify::height', () =>
                (this.translation_y = -this.height));
        }

        // Ensure staticBox is updated before visibility mode
        this._updateStaticBox();

        this._updateVisibilityMode();

        // In case we are already inside the overview when the extension is loaded,
        // for instance on unlocking the screen if it was locked with the overview open.
        if (Main.overview.visibleTarget)
            this._onOverviewShowing();

        this._updateAutoHideBarriers();
    }

    _onDestroy() {
        // Clean up any active spring animation
        if (this._activeSpringAnimation) {
            this._activeSpringAnimation.destroy();
            this._activeSpringAnimation = null;
        }

        // The dash, intellihide and themeManager have global signals as well internally
        this.dash.destroy();
        this._intellihide.destroy();
        this._themeManager.destroy();
        this._workspaceSwitcherPopup?.destroy();
        this._stopScreencastPulse();
        this._screencastIndicator = null;
        delete this._staticBox;

        if (this._marginLater) {
            Utils.laterRemove(this._marginLater);
            delete this._marginLater;
        }

        if (this._triggerTimeoutId) {
            GLib.source_remove(this._triggerTimeoutId);
            this._triggerTimeoutId = 0;
        }

        if (this._hoverCheckId) {
            GLib.source_remove(this._hoverCheckId);
            this._hoverCheckId = 0;
        }

        this._restoreUnredirect();

        // Remove barrier timeout
        if (this._removeBarrierTimeoutId > 0)
            GLib.source_remove(this._removeBarrierTimeoutId);

        // Remove existing barrier
        this._removeBarrier();

        // Remove pointer watcher
        if (this._dockWatch) {
            PointerWatcher.getPointerWatcher()._removeWatch(this._dockWatch);
            this._dockWatch = null;
        }

        // Cancel any pending dock dwell timeout
        this._cancelDockDwell();

        if (this._optionalScrollWorkspaceSwitchDeadTimeId) {
            GLib.source_remove(this._optionalScrollWorkspaceSwitchDeadTimeId);
            delete this._optionalScrollWorkspaceSwitchDeadTimeId;
        }
    }

    _updateAutoHideBarriers() {
        // Remove pointer watcher
        if (this._dockWatch) {
            PointerWatcher.getPointerWatcher()._removeWatch(this._dockWatch);
            this._dockWatch = null;
        }

        // Setup pressure barrier (GS38+ only)
        this._updatePressureBarrier();
        this._updateBarrier();

        // setup dwelling system if pressure barriers are not available
        this._setupDockDwellIfNeeded();
    }

    _bindSettingsChanges() {
        const {settings} = DockManager;
        this._signalsHandler.add([
            settings,
            'changed::scroll-action',
            () => {
                this._optionalScrollWorkspaceSwitch();
            },
        ], [
            settings,
            'changed::dash-max-icon-size',
            () => {
                this.dash.setIconSize(settings.dashMaxIconSize);
            },
        ], [
            settings,
            'changed::icon-size-fixed',
            () => {
                this.dash.setIconSize(settings.dashMaxIconSize);
            },
        ], [
            settings,
            'changed::dock-margin-size',
            this._resetPosition.bind(this),
        ], [
            settings,
            'changed::show-favorites',
            () => {
                this.dash.resetAppIcons();
            },
        ], [
            settings,
            'changed::show-trash',
            () => {
                this.dash.resetAppIcons();
            },
            Utils.SignalsHandlerFlags.CONNECT_AFTER,
        ], [
            settings,
            'changed::show-mounts',
            () => {
                this.dash.resetAppIcons();
            },
            Utils.SignalsHandlerFlags.CONNECT_AFTER,
        ], [
            settings,
            'changed::isolate-locations',
            () => this.dash.resetAppIcons(),
            Utils.SignalsHandlerFlags.CONNECT_AFTER,
        ], [
            settings,
            'changed::dance-urgent-applications',
            () => this.dash.resetAppIcons(),
            Utils.SignalsHandlerFlags.CONNECT_AFTER,
        ], [
            settings,
            'changed::bounce-icons',
            () => this.dash.resetAppIcons(),
            Utils.SignalsHandlerFlags.CONNECT_AFTER,
        ], [
            settings,
            'changed::show-running',
            () => {
                this.dash.resetAppIcons();
            },
        ], [
            settings,
            'changed::group-apps',
            () => {
                this.dash.resetAppIcons();
            },
        ], [
            settings,
            'changed::show-apps-always-in-the-edge',
            () => {
                this.dash.updateShowAppsButton();
            },
        ], [
            settings,
            'changed::show-apps-at-top',
            () => {
                this.dash.updateShowAppsButton();
            },
        ], [
            settings,
            'changed::show-show-apps-button',
            () => {
                if (!Main.overview.isDummy &&
                        settings.showShowAppsButton)
                    this.dash.showShowAppsButton();
                else
                    this.dash.hideShowAppsButton();
            },
        ], [
            settings,
            'changed::dock-fixed',
            () => {
                this._untrackDock();
                this._trackDock();

                this._updateAutoHideBarriers();
                this._updateVisibilityMode();
            },
        ], [
            settings,
            'changed::manualhide',
            () => {
                this._updateVisibilityMode();
            },
        ], [
            settings,
            'changed::intellihide',
            () => {
                this._updateVisibilityMode();
                this._updateVisibleDesktop();
            },
        ], [
            settings,
            'changed::intellihide-mode',
            () => {
                this._intellihide.forceUpdate();
            },
        ], [
            settings,
            'changed::autohide',
            () => {
                this._updateVisibilityMode();
                this._updateAutoHideBarriers();
            },
        ], [
            settings,
            'changed::autohide-in-fullscreen',
            this._updateBarrier.bind(this),
        ], [
            settings,
            'changed::show-dock-urgent-notify',
            () => {
                this.dash.resetAppIcons();
            },
        ],
        [
            settings,
            'changed::extend-height',
            this._resetPosition.bind(this),
        ], [
            settings,
            'changed::height-fraction',
            this._resetPosition.bind(this),
        ], [
            settings,
            'changed::always-center-icons',
            () => this.dash.resetAppIcons(),
        ], [
            settings,
            'changed::require-pressure-to-show',
            () => this._updateAutoHideBarriers(),
        ], [
            settings,
            'changed::pressure-threshold',
            () => {
                this._updatePressureBarrier();
                this._updateBarrier();
            },
        ]);
    }

    _disableUnredirect() {
        // Do not disable unredirection when a monitor is in fullscreen.
        // Disabling unredirect forces the compositor to composite every
        // frame, which breaks VRR/Freesync on fullscreen applications.
        // The dock should not need to be rendered on top of a fullscreen
        // surface anyway (unless autohide-in-fullscreen is explicitly
        // enabled, which has its own visibility logic) (#62).
        if (this._monitor?.inFullscreen)
            return;

        if (!this._unredirectDisabled) {
            if (Meta.disable_unredirect_for_display !== undefined)
                Meta.disable_unredirect_for_display(global.display);
            else if (global.compositor.disable_unredirect !== undefined)
                global.compositor.disable_unredirect();
            this._unredirectDisabled = true;
        }
    }

    _restoreUnredirect() {
        if (this._unredirectDisabled) {
            if (Meta.enable_unredirect_for_display !== undefined)
                Meta.enable_unredirect_for_display(global.display);
            else if (global.compositor.enable_unredirect !== undefined)
                global.compositor.enable_unredirect();
            this._unredirectDisabled = false;
        }
    }

    /**
     * This is call when visibility settings change
     */
    _updateVisibilityMode() {
        const {settings} = DockManager;
        if (DockManager.settings.dockFixed || DockManager.settings.manualhide) {
            this._autohideIsEnabled = false;
            this._intellihideIsEnabled = false;
        } else {
            this._autohideIsEnabled = settings.autohide;
            this._intellihideIsEnabled = settings.intellihide;
        }

        if (this._autohideIsEnabled) {
            this.add_style_class_name('autohide');
            // Reset ignore hover when autohide is enabled
            this._ignoreHover = false;
        } else {
            this.remove_style_class_name('autohide');
        }

        if (this._intellihideIsEnabled) {
            this._intellihide.enable();
        } else {
            this._intellihide.disable();
            this._restoreUnredirect();
        }

        this._updateDashVisibility();
    }

    /**
     * Show/hide dash based on, in order of priority:
     * overview visibility
     * fixed mode
     * intellihide
     * autohide
     * overview visibility
     */
    _updateDashVisibility() {
        // GNOME 50: Chrome actors with affectsStruts can be hidden by the
        // Shell during struts recalculation (overview, minimize, restack).
        const {panelBox} = Main.layoutManager;
        if (panelBox && !panelBox.visible) {
            panelBox.visible = true;
            panelBox.show();
        }

        [this, this._slider, this._box, this.dash].forEach(actor => {
            if (actor && !actor.visible) {
                actor.visible = true;
                actor.show();
            }
        });

        if (DockManager.settings.manualhide) {
            this._ignoreHover = true;
            this._removeAnimations();
            this._animateOut(0, 0);
            return;
        }

        if (Main.overview.visibleTarget)
            return;

        const {settings} = DockManager;

        // When autohide-in-fullscreen is enabled and this monitor is in
        // fullscreen, force-hide the dock.  Some apps (notably Firefox)
        // use client-side fullscreen which may not be detected by the
        // Chrome tracking layer, so we check explicitly here.
        if (settings.autohideInFullscreen && this._monitor.inFullscreen) {
            this._ignoreHover = false;
            this._animateOut(settings.animationTime, 0);
            return;
        }

        if (DockManager.settings.dockFixed) {
            // In fixed mode the dock must be fully visible at all times.
            // Set slideX directly instead of animating to avoid any
            // residual offset caused by interrupted animations or
            // spring-overshoot clamping (issue #2576).
            this._removeAnimations();
            this._slider.slideX = 1.0;
            this._dockState = State.SHOWN;
            this.dash.iconAnimator.start();
        } else if (this._intellihideIsEnabled) {
            if (!this.dash.requiresVisibility && this._intellihide.getOverlapStatus()) {
                this._ignoreHover = false;
                // Do not hide if autohide is enabled and mouse is hover
                if (!this._box.hover || !this._autohideIsEnabled)
                    this._animateOut(settings.animationTime, 0);
            } else {
                this._ignoreHover = true;
                this._removeAnimations();
                this._animateIn(settings.animationTime, 0);
            }
        } else if (this._autohideIsEnabled) {
            this._ignoreHover = false;

            if (this._box.hover || this.dash.requiresVisibility)
                this._animateIn(settings.animationTime, 0);
            else
                this._animateOut(settings.animationTime, 0);
        } else {
            this._animateOut(settings.animationTime, 0);
        }
    }

    _onOverviewShowing() {
        this.add_style_class_name('overview');

        this._ignoreHover = true;
        this._intellihide.disable();
        this._removeAnimations();
        this._animateIn(DockManager.settings.animationTime, 0);
    }

    _onOverviewHiding() {
        this._ignoreHover = false;
        this._intellihide.enable();
        this._updateDashVisibility();
    }

    _onOverviewHidden() {
        this.remove_style_class_name('overview');

        // GNOME 50: panelBox.visible becomes false during the overview-to-desktop
        // transition when an extension registers Chrome actors with affectsStruts.
        const {panelBox} = Main.layoutManager;
        if (panelBox && !panelBox.visible) {
            panelBox.visible = true;
            panelBox.show();
        }

        // GNOME 50: same root cause hides dock actor tree.
        if (!this.visible) {
            this.visible = true;
            this.show();
        }
        if (this._slider && !this._slider.visible) {
            this._slider.visible = true;
            this._slider.show();
        }
        if (this._box && !this._box.visible) {
            this._box.visible = true;
            this._box.show();
        }
        if (this.dash && !this.dash.visible) {
            this.dash.visible = true;
            this.dash.show();
        }

        if (this._box?.get_stage())
            this._box.sync_hover();
        // Force intellihide to recheck overlap after overview is hidden
        if (this._intellihideIsEnabled)
            this._intellihide.forceUpdate();
        this._updateDashVisibility();
    }

    _onMenuOpened() {
        this._ignoreHover = true;
    }

    _onMenuClosed() {
        this._ignoreHover = false;
        if (this._box?.get_stage())
            this._box.sync_hover();
        this._hoverChanged();
        this._updateDashVisibility();
    }

    _onMagnificationChanged(_dash, enabled) {
        if (enabled) {
            const {settings} = DockManager;
            const maxScale = Math.max(1.0, Math.min(3.0,
                settings.iconMagnificationFactor));
            const overflow = this.dash.iconSize * maxScale;
            this._box.set_clip_to_allocation(false);
            this._slider.set_clip_to_allocation(false);
            this.set_clip_to_allocation(false);
            this._box.remove_clip();
            this._slider.remove_clip();
            this.remove_clip();
            this._box.clip_to_view = false;
            this._magClipViewId = this._box.connect('notify::allocation', () => {
                if (!this._box.clip_to_view)
                    return;
                if (this._magClipIdleId)
                    return;
                this._magClipIdleId = GLib.idle_add(GLib.PRIORITY_DEFAULT, () => {
                    this._magClipIdleId = 0;
                    if (this._box.clip_to_view)
                        this._box.clip_to_view = false;
                    return GLib.SOURCE_REMOVE;
                });
            });
            this._slider.magnificationOverflow = overflow;
        } else {
            this._box.set_clip_to_allocation(true);
            this._slider.set_clip_to_allocation(true);
            this.set_clip_to_allocation(true);
            if (this._magClipViewId) {
                this._box.disconnect(this._magClipViewId);
                this._magClipViewId = 0;
            }
            if (this._magClipIdleId) {
                GLib.source_remove(this._magClipIdleId);
                this._magClipIdleId = 0;
            }
            this._box.clip_to_view = true;
            this._slider.magnificationOverflow = 0;
        }
    }

    _hoverChanged() {
        // Check if any preview menus are open
        let hasOpenPreviewMenu = false;
        this.dash.getAppIcons().forEach(appIcon => {
            if (appIcon._previewMenu?.isOpen)
                hasOpenPreviewMenu = true;
        });

        if (!this._ignoreHover && !hasOpenPreviewMenu) {
            // Never show the dock via hover when the monitor is in fullscreen
            // and autohide-in-fullscreen is enabled (multi-monitor case).
            if (DockManager.settings.autohideInFullscreen &&
                this._monitor.inFullscreen) {
                this._hide();
                return;
            }

            // Skip if dock is not in autohide mode for instance because it is shown
            // by intellihide.
            if (this._autohideIsEnabled) {
                if (this._box.hover || Main.overview.visible) {
                    this._show();

                    // Safety net for multi-monitor setups: when the pointer
                    // crosses the dock very quickly (e.g. moving between
                    // monitors), the leave event can be lost, leaving the
                    // dock stuck visible.  Schedule a deferred re-check to
                    // resync the hover state (#54).
                    if (this._hoverCheckId)
                        GLib.source_remove(this._hoverCheckId);
                    this._hoverCheckId = GLib.timeout_add(
                        GLib.PRIORITY_DEFAULT, 500, () => {
                            this._hoverCheckId = 0;
                            if (this._box?.get_stage())
                                this._box.sync_hover();
                            return GLib.SOURCE_REMOVE;
                        });
                } else {
                    this._hide();
                }
            }
        }
    }

    getDockState() {
        return this._dockState;
    }

    _show() {
        this._delayedHide = false;
        if ((this._dockState === State.HIDDEN) || (this._dockState === State.HIDING)) {
            if (this._dockState === State.HIDING)
                // suppress all potential queued transitions - i.e. added but not started,
                // always give priority to show
                this._removeAnimations();

            this.emit('showing');
            this._animateIn(DockManager.settings.animationTime, 0);
        }
    }

    _hide() {
        // If no hiding animation is running or queued
        if ((this._dockState === State.SHOWN) || (this._dockState === State.SHOWING)) {
            const {settings} = DockManager;
            const delay = settings.hideDelay;

            if (this._dockState === State.SHOWING) {
                // if a show already started, let it finish; queue hide without removing the show.
                // to obtain this, we wait for the animateIn animation to be completed
                this._delayedHide = true;
                return;
            }

            this.emit('hiding');
            this._animateOut(settings.animationTime, delay);
        }
    }

    _animateIn(time, delay) {
        if (this._intellihideIsEnabled)
            this._disableUnredirect();
        this._dockState = State.SHOWING;
        this.dash.iconAnimator.start();
        this._delayedHide = false;

        const onComplete = () => {
            this._dockState = State.SHOWN;
            // Remove barrier so that mouse pointer is released and can
            // monitors on other side of dock.
            // NOTE: Delay needed to keep mouse from moving past dock and
            // re-hiding dock immediately. This gives users an opportunity
            // to hover over the dock
            if (this._removeBarrierTimeoutId > 0)
                GLib.source_remove(this._removeBarrierTimeoutId);

            if (!this._delayedHide) {
                this._removeBarrierTimeoutId = GLib.timeout_add(
                    GLib.PRIORITY_DEFAULT, 100, this._removeBarrier.bind(this));
            } else {
                this._hide();
            }
        };

        if (SpringAnimation && DockManager.settings.springAnimations && time > 0) {
            this._slider.remove_all_transitions();
            if (this._activeSpringAnimation) {
                this._activeSpringAnimation.destroy();
                this._activeSpringAnimation = null;
            }

            // Slightly underdamped for ~10% overshoot on show
            const overshootClamp = DockManager.settings.springOvershootClamp ?? 1.15;
            this._activeSpringAnimation = new SpringAnimation.SpringAnimation({
                stiffness: DockManager.settings.springStiffness ?? 200,
                damping: DockManager.settings.springDamping ?? 18,
                mass: 1,
                target: 1.0,
                initial: this._slider.slideX,
                actor: this._slider,
                onUpdate: value => {
                    this._slider.slideX = Math.max(0, Math.min(value, overshootClamp));
                },
                onComplete: () => {
                    this._activeSpringAnimation = null;
                    // Ensure we land exactly at 1.0
                    this._slider.slideX = 1.0;
                    onComplete();
                },
            });
            this._activeSpringAnimation.start();
        } else {
            this._slider.ease_property('slide-x', 1, {
                duration: time * 1000,
                delay: delay * 1000,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                onComplete,
            });
        }
    }

    _animateOut(time, delay) {
        this._dockState = State.HIDING;

        const onComplete = () => {
            this._dockState = State.HIDDEN;
            if (this._intellihideIsEnabled)
                this._restoreUnredirect();
            // Remove queued barrier removal timeout if any
            if (this._removeBarrierTimeoutId > 0)
                GLib.source_remove(this._removeBarrierTimeoutId);
            this._updateBarrier();
            this.dash.iconAnimator.pause();
        };

        if (SpringAnimation && DockManager.settings.springAnimations && time > 0) {
            this._slider.remove_all_transitions();
            if (this._activeSpringAnimation) {
                this._activeSpringAnimation.destroy();
                this._activeSpringAnimation = null;
            }

            // Critically damped for smooth hide without overshoot
            const hideOvershootClamp = DockManager.settings.springOvershootClamp ?? 1.15;
            this._activeSpringAnimation = new SpringAnimation.SpringAnimation({
                stiffness: DockManager.settings.springStiffness ?? 200,
                damping: (DockManager.settings.springDamping ?? 18) + 10,
                mass: 1,
                target: 0.0,
                initial: this._slider.slideX,
                actor: this._slider,
                onUpdate: value => {
                    this._slider.slideX = Math.max(0, Math.min(value, hideOvershootClamp));
                },
                onComplete: () => {
                    this._activeSpringAnimation = null;
                    // Ensure we land exactly at 0.0
                    this._slider.slideX = 0.0;
                    onComplete();
                },
            });
            this._activeSpringAnimation.start();
        } else {
            this._slider.ease_property('slide-x', 0, {
                duration: time * 1000,
                delay: delay * 1000,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                onComplete,
            });
        }
    }

    /**
     * Dwelling system based on the GNOME Shell 3.14 messageTray code.
     */
    _setupDockDwellIfNeeded() {
        // If we don't have extended barrier features, then we need
        // to support the old tray dwelling mechanism.
        if (this._autohideIsEnabled &&
            (!Utils.supportsExtendedBarriers() ||
             !DockManager.settings.requirePressureToShow)) {
            const pointerWatcher = PointerWatcher.getPointerWatcher();
            this._dockWatch = pointerWatcher.addWatch(
                DockManager.settings.dockDwellCheckInterval ?? DOCK_DWELL_CHECK_INTERVAL,
                this._checkDockDwell.bind(this));
            this._dockDwelling = false;
            this._dockDwellUserTime = 0;
        }
    }

    _checkDockDwell(x, y) {
        const workArea = Main.layoutManager.getWorkAreaForMonitor(this._monitor.index);
        const edgePx = DockManager.settings.dockEdgeDwellWidth ?? DOCK_DWELL_EDGE_PX;
        let shouldDwell;
        // Check for the correct screen edge, extending the sensitive area to the whole workarea,
        // minus edgePx to avoid conflicting with other active corners.
        if (this._position === St.Side.LEFT) {
            shouldDwell = (x <= this._monitor.x + edgePx) && (y > workArea.y) &&
                (y < workArea.y + workArea.height);
        } else if (this._position === St.Side.RIGHT) {
            shouldDwell = (x >= this._monitor.x + this._monitor.width - edgePx) &&
                (y > workArea.y) && (y < workArea.y + workArea.height);
        } else if (this._position === St.Side.TOP) {
            shouldDwell = (y <= this._monitor.y + edgePx) && (x > workArea.x) &&
                (x < workArea.x + workArea.width);
        } else if (this._position === St.Side.BOTTOM) {
            shouldDwell = (y >= this._monitor.y + this._monitor.height - edgePx) &&
                (x > workArea.x) && (x < workArea.x + workArea.width);
        }

        if (shouldDwell) {
            // We only set up dwell timeout when the user is not hovering over the dock
            // already (!this._box.hover).
            // The _dockDwelling variable is used so that we only try to
            // fire off one dock dwell - if it fails (because, say, the user has the mouse down),
            // we don't try again until the user moves the mouse up and down again.
            if (!this._dockDwelling && !this._box.hover && (this._dockDwellTimeoutId === 0)) {
                // Save the interaction timestamp so we can detect user input
                const focusWindow = global.display.focus_window;
                this._dockDwellUserTime = focusWindow ? focusWindow.user_time : 0;

                this._dockDwellTimeoutId = GLib.timeout_add(
                    GLib.PRIORITY_DEFAULT,
                    DockManager.settings.showDelay * 1000,
                    this._dockDwellTimeout.bind(this));
                GLib.Source.set_name_by_id(this._dockDwellTimeoutId,
                    '[xdock] this._dockDwellTimeout');
            }
            this._dockDwelling = true;
        } else {
            this._cancelDockDwell();
            this._dockDwelling = false;
        }
    }

    _cancelDockDwell() {
        if (this._dockDwellTimeoutId !== 0) {
            GLib.source_remove(this._dockDwellTimeoutId);
            this._dockDwellTimeoutId = 0;
        }
    }

    _dockDwellTimeout() {
        this._dockDwellTimeoutId = 0;

        if (!DockManager.settings.autohideInFullscreen &&
            this._monitor.inFullscreen)
            return GLib.SOURCE_REMOVE;

        // We don't want to open the tray when a modal dialog
        // is up, so we check the modal count for that. When we are in the
        // overview we have to take the overview's modal push into account
        if (Main.modalCount > (Main.overview.visible ? 1 : 0))
            return GLib.SOURCE_REMOVE;

        // If the user interacted with the focus window since we started the tray
        // dwell (by clicking or typing), don't activate the message tray
        const focusWindow = global.display.focus_window;
        const currentUserTime = focusWindow ? focusWindow.user_time : 0;
        if (currentUserTime !== this._dockDwellUserTime)
            return GLib.SOURCE_REMOVE;

        // Reuse the pressure version function, the logic is the same
        this._onPressureSensed();
        return GLib.SOURCE_REMOVE;
    }

    _updatePressureBarrier() {
        const {settings} = DockManager;
        this._canUsePressure = Utils.supportsExtendedBarriers();
        const {pressureThreshold} = settings;

        // Remove existing pressure barrier
        if (this._pressureBarrier) {
            this._pressureBarrier.disconnectObject(this);
            this._pressureBarrier.destroy();
            this._pressureBarrier = null;
        }

        if (this._barrier) {
            this._barrier.destroy();
            this._barrier = null;
        }

        // Create new pressure barrier based on pressure threshold setting
        if (this._canUsePressure && this._autohideIsEnabled &&
            DockManager.settings.requirePressureToShow) {
            this._pressureBarrier = new Layout.PressureBarrier(
                pressureThreshold, settings.showDelay * 1000,
                Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW);
            this._pressureBarrier.connectObject('trigger', () => {
                if (!settings.autohideInFullscreen && this._monitor.inFullscreen)
                    return;
                this._onPressureSensed();
            }, this);
        }
    }

    /**
     * handler for mouse pressure sensed
     */
    _onPressureSensed() {
        if (Main.overview.visibleTarget)
            return;

        if (this._triggerTimeoutId)
            GLib.source_remove(this._triggerTimeoutId);

        // In case the mouse move away from the dock area before hovering it,
        // in such case the leave event would never be triggered and the dock
        // would stay visible forever.
        this._triggerTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT,
            DockManager.settings.pressureShowTimeout ?? 250, () => {
            // Guard against accessing destroyed state
                if (!this._staticBox || !this._monitor) {
                    this._triggerTimeoutId = 0;
                    return GLib.SOURCE_REMOVE;
                }
                const [x, y, mods_] = global.get_pointer();
                let shouldHide = true;
                switch (this._position) {
                case St.Side.LEFT:
                    if (x <= this._staticBox.x2 &&
                    x >= this._monitor.x &&
                    y >= this._monitor.y &&
                    y <= this._monitor.y + this._monitor.height)
                        shouldHide = false;

                    break;
                case St.Side.RIGHT:
                    if (x >= this._staticBox.x1 &&
                    x <= this._monitor.x + this._monitor.width &&
                    y >= this._monitor.y &&
                    y <= this._monitor.y + this._monitor.height)
                        shouldHide = false;

                    break;
                case St.Side.TOP:
                    if (x >= this._monitor.x &&
                    x <= this._monitor.x + this._monitor.width &&
                    y <= this._staticBox.y2 &&
                    y >= this._monitor.y)
                        shouldHide = false;

                    break;
                case St.Side.BOTTOM:
                    if (x >= this._monitor.x &&
                    x <= this._monitor.x + this._monitor.width &&
                    y >= this._staticBox.y1 &&
                    y <= this._monitor.y + this._monitor.height)
                        shouldHide = false;
                }
                if (shouldHide) {
                    this._triggerTimeoutId = 0;
                    this._hoverChanged();
                    return GLib.SOURCE_REMOVE;
                } else {
                    return GLib.SOURCE_CONTINUE;
                }
            });

        this._show();
    }

    /**
     * Remove pressure barrier
     */
    _removeBarrier() {
        if (this._barrier) {
            if (this._pressureBarrier)
                this._pressureBarrier.removeBarrier(this._barrier);
            this._barrier.destroy();
            this._barrier = null;
        }
        this._removeBarrierTimeoutId = 0;
        return false;
    }

    /**
     * Update pressure barrier size
     */
    _updateBarrier() {
        // Remove existing barrier
        this._removeBarrier();

        // The barrier needs to be removed in fullscreen with autohide disabled
        // otherwise the mouse can get trapped on monitor.
        if (this._monitor.inFullscreen &&
            !DockManager.settings.autohideInFullscreen)
            return;

        // Manually reset pressure barrier
        // This is necessary because we remove the pressure barrier when it is
        // triggered to show the dock
        if (this._pressureBarrier) {
            this._pressureBarrier._reset();
            this._pressureBarrier._isTriggered = false;
        }

        // Create new barrier
        // The barrier extends to the whole workarea, minus edgePx
        // to avoid conflicting with other active corners
        // Note: dash in fixed position doesn't use pressure barrier.
        if (this._canUsePressure && this._autohideIsEnabled &&
            DockManager.settings.requirePressureToShow) {
            let x1, x2, y1, y2, direction;
            const workArea = Main.layoutManager.getWorkAreaForMonitor(
                this._monitor.index);
            const edgePx = DockManager.settings.dockEdgeDwellWidth ?? DOCK_DWELL_EDGE_PX;

            if (this._position === St.Side.LEFT) {
                x1 = this._monitor.x + edgePx;
                x2 = x1;
                y1 = workArea.y + edgePx;
                y2 = workArea.y + workArea.height - edgePx;
                direction = Meta.BarrierDirection.POSITIVE_X;
            } else if (this._position === St.Side.RIGHT) {
                x1 = this._monitor.x + this._monitor.width - edgePx;
                x2 = x1;
                y1 = workArea.y + edgePx;
                y2 = workArea.y + workArea.height - edgePx;
                direction = Meta.BarrierDirection.NEGATIVE_X;
            } else if (this._position === St.Side.TOP) {
                x1 = workArea.x + edgePx;
                x2 = workArea.x + workArea.width - edgePx;
                y1 = this._monitor.y + edgePx;
                y2 = y1;
                direction = Meta.BarrierDirection.POSITIVE_Y;
            } else if (this._position === St.Side.BOTTOM) {
                x1 = workArea.x + edgePx;
                x2 = workArea.x + workArea.width - edgePx;
                y1 = this._monitor.y + this._monitor.height - edgePx;
                y2 = y1;
                direction = Meta.BarrierDirection.NEGATIVE_Y;
            }

            if (this._pressureBarrier && this._dockState === State.HIDDEN) {
                this._barrier = new Meta.Barrier({
                    backend: global.backend,
                    x1,
                    x2,
                    y1,
                    y2,
                    directions: direction,
                });
                this._pressureBarrier.addBarrier(this._barrier);
            }
        }
    }

    _isPrimaryMonitor() {
        return this.monitorIndex === Main.layoutManager.primaryIndex;
    }

    _resetPosition() {
        // Ensure variables linked to settings are updated.
        this._updateVisibilityMode();

        const {
            dockFixed: fixedIsEnabled,
            dockExtended: extendHeight,
            dockMarginSize: margin,
        } = DockManager.settings;

        if (fixedIsEnabled)
            this.add_style_class_name('fixed');
        else
            this.remove_style_class_name('fixed');

        // Note: do not use the workarea coordinates in the direction on which the dock is placed,
        // to avoid a loop [position change -> workArea change -> position change] with
        // fixed dock.
        const workArea = Main.layoutManager.getWorkAreaForMonitor(this.monitorIndex);

        let fraction = DockManager.settings.heightFraction;
        if (extendHeight)
            fraction = 1;
        else if ((fraction < 0) || (fraction > 1))
            fraction = 0.95;

        if (this._isHorizontal) {
            this.width = Math.round(fraction * workArea.width);

            let posY = this._monitor.y;
            if (this._position === St.Side.BOTTOM)
                posY += this._monitor.height;

            this.x = workArea.x + Math.round((1 - fraction) / 2 * workArea.width);
            this.y = posY;

            if (extendHeight) {
                this.dash._container.set_width(this.width - margin * 2);
                this.add_style_class_name('extended');
            } else {
                this.dash._container.set_width(-1);
                this.remove_style_class_name('extended');
            }
        } else {
            this.height = Math.round(fraction * workArea.height);

            let posX = this._monitor.x;
            if (this._position === St.Side.RIGHT)
                posX += this._monitor.width;

            this.x = posX;
            this.y = workArea.y + Math.round((1 - fraction) / 2 * workArea.height);

            if (extendHeight) {
                this.dash._container.set_height(this.height - margin * 2);
                this.add_style_class_name('extended');
            } else {
                this.dash._container.set_height(-1);
                this.remove_style_class_name('extended');
            }
        }

        if (margin > 0)
            this.add_style_class_name('dock-margin');
        else
            this.remove_style_class_name('dock-margin');
    }

    _updateVisibleDesktop() {
        if (!this._intellihideIsEnabled)
            return;

        const {desktopIconsUsableArea} = DockManager.getDefault() ?? {};
        if (!desktopIconsUsableArea)
            return;
        if (this._position === St.Side.BOTTOM)
            desktopIconsUsableArea.setMargins(this.monitorIndex, 0, this._box.height, 0, 0);
        else if (this._position === St.Side.TOP)
            desktopIconsUsableArea.setMargins(this.monitorIndex, this._box.height, 0, 0, 0);
        else if (this._position === St.Side.RIGHT)
            desktopIconsUsableArea.setMargins(this.monitorIndex, 0, 0, 0, this._box.width);
        else if (this._position === St.Side.LEFT)
            desktopIconsUsableArea.setMargins(this.monitorIndex, 0, 0, this._box.width, 0);
    }

    _updateStaticBox() {
        // Guard: skip if the dock's box is not on stage (e.g. during
        // destruction or workspace switch transitions).  Calling
        // get_transformed_position on an unmapped actor triggers warnings
        // and can contribute to SIGSEGV crashes.
        if (!this._box?.get_stage())
            return;

        // Base the static box on transformed coordinates, then normalize only the
        // sliding axis so overlap checks always use the fully visible dock edge.
        let [staticX, staticY] = this._box.get_transformed_position();
        const {width} = this._box;
        const {height} = this._box;

        switch (this._position) {
        case St.Side.LEFT:
            staticX = this._monitor.x;
            break;
        case St.Side.RIGHT:
            staticX = this._monitor.x + this._monitor.width - width;
            break;
        case St.Side.TOP:
            staticY = this._monitor.y;
            break;
        case St.Side.BOTTOM:
            staticY = this._monitor.y + this._monitor.height - height;
            break;
        }

        this._staticBox.init_rect(
            staticX,
            staticY,
            width,
            height
        );

        this._intellihide.updateTargetBox(this._staticBox);
        this._updateVisibleDesktop();
    }

    _removeAnimations() {
        this._slider.remove_all_transitions();
        if (this._activeSpringAnimation) {
            this._activeSpringAnimation.destroy();
            this._activeSpringAnimation = null;
        }
    }

    _onDragStart() {
        this._oldIgnoreHover = this._ignoreHover;
        this._ignoreHover = true;
        this._animateIn(DockManager.settings.animationTime, 0);
    }

    _onDragEnd() {
        if (this._oldIgnoreHover)
            this._ignoreHover = this._oldIgnoreHover;
        this._oldIgnoreHover = null;
        if (this._box?.get_stage())
            this._box.sync_hover();
        this._updateDashVisibility();
    }

    /**
     * Show dock and give key focus to it
     */
    _onAccessibilityFocus(timestamp) {
        if (!Main.overview.visible)
            global.display.unset_input_focus(timestamp);
        this._box.navigate_focus(null, St.DirectionType.TAB_FORWARD, false);
        this._animateIn(DockManager.settings.animationTime, 0);
    }

    _updateScreencastIndicator() {
        const screencastMonitor = DockManager.getDefault()?.screencastMonitor;
        if (!screencastMonitor || !this._screencastIndicator)
            return;

        const shouldShow = screencastMonitor.isRecording;

        if (shouldShow && !this._screencastIndicator.visible) {
            this._screencastIndicator.visible = true;
            this._screencastIndicator.ease({
                opacity: 255,
                duration: 300,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            });
            // Pulse animation: continuously fade in/out
            this._startScreencastPulse();
        } else if (!shouldShow && this._screencastIndicator.visible) {
            this._stopScreencastPulse();
            this._screencastIndicator.ease({
                opacity: 0,
                duration: 300,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
                onComplete: () => {
                    this._screencastIndicator.visible = false;
                },
            });
        }
    }

    _startScreencastPulse() {
        this._stopScreencastPulse();

        const pulse = () => {
            if (!this._screencastIndicator?.visible)
                return;

            this._screencastIndicator.ease({
                opacity: 80,
                duration: 1000,
                mode: Clutter.AnimationMode.EASE_IN_OUT_SINE,
                onComplete: () => {
                    if (!this._screencastIndicator?.visible)
                        return;

                    this._screencastIndicator.ease({
                        opacity: 255,
                        duration: 1000,
                        mode: Clutter.AnimationMode.EASE_IN_OUT_SINE,
                        onComplete: pulse,
                    });
                },
            });
        };

        pulse();
    }

    _stopScreencastPulse() {
        this._screencastIndicator?.remove_all_transitions();
    }

    // Optional features to be enabled only for the main Dock
    _enableExtraFeatures() {
        // Restore dash accessibility
        Main.ctrlAltTabManager.addGroup(
            this.dash, _('Dash'), 'user-bookmarks-symbolic',
            {focusCallback: timestamp => this._onAccessibilityFocus(timestamp)});
    }

    /**
     * Switch workspace by scrolling over the dock
     */
    _optionalScrollWorkspaceSwitch() {
        const isEnabled = () =>
            DockManager.settings.scrollAction === scrollAction.SWITCH_WORKSPACE;

        const enable = () => {
            this._signalsHandler.removeWithLabel(Labels.WORKSPACE_SWITCH_SCROLL);

            this._signalsHandler.addWithLabel(Labels.WORKSPACE_SWITCH_SCROLL,
                this._box, 'scroll-event', (_, e) => onScrollEvent(e));
        };

        const disable = () => {
            this._signalsHandler.removeWithLabel(Labels.WORKSPACE_SWITCH_SCROLL);

            if (this._optionalScrollWorkspaceSwitchDeadTimeId) {
                GLib.source_remove(this._optionalScrollWorkspaceSwitchDeadTimeId);
                this._optionalScrollWorkspaceSwitchDeadTimeId = 0;
            }
        };

        if (isEnabled())
            enable();
        else
            disable();

        // This was inspired to desktop-scroller@obsidien.github.com
        const onScrollEvent = event => {
            // When in overview change workspace only in windows view
            if (Main.overview.visible)
                return false;

            const activeWs = global.workspace_manager.get_active_workspace();
            let direction = null;

            let prevDirection, nextDirection;
            if (global.workspace_manager.layout_columns > global.workspace_manager.layout_rows) {
                prevDirection = Meta.MotionDirection.UP;
                nextDirection = Meta.MotionDirection.DOWN;
            } else {
                prevDirection = Meta.MotionDirection.LEFT;
                nextDirection = Meta.MotionDirection.RIGHT;
            }

            switch (event.get_scroll_direction()) {
            case Clutter.ScrollDirection.UP:
                direction = prevDirection;
                break;
            case Clutter.ScrollDirection.DOWN:
                direction = nextDirection;
                break;
            case Clutter.ScrollDirection.SMOOTH: {
                const [dx_, dy] = event.get_scroll_delta();
                if (dy < 0)
                    direction = prevDirection;
                else if (dy > 0)
                    direction = nextDirection;
            }
                break;
            }

            if (direction) {
                // Prevent scroll events from triggering too many workspace switches
                // by adding a dead time between each scroll event.
                // Useful on laptops when using a touch pad.

                // During the deadtime do nothing
                if (this._optionalScrollWorkspaceSwitchDeadTimeId) {
                    return false;
                } else {
                    this._optionalScrollWorkspaceSwitchDeadTimeId = GLib.timeout_add(
                        GLib.PRIORITY_DEFAULT,
                        DockManager.settings.scrollWorkspaceDeadtime ?? 250, () => {
                            this._optionalScrollWorkspaceSwitchDeadTimeId = 0;
                        });
                }

                let ws;

                ws = activeWs.get_neighbor(direction);

                if (!Main.wm._workspaceSwitcherPopup) {
                    // Support Workspace Grid extension showing their custom
                    // Grid Workspace Switcher
                    if (global.workspace_manager.workspace_grid !== undefined) {
                        Main.wm._workspaceSwitcherPopup =
                            global.workspace_manager.workspace_grid.getWorkspaceSwitcherPopup();
                    } else {
                        Main.wm._workspaceSwitcherPopup = new WorkspaceSwitcherPopup.WorkspaceSwitcherPopup();
                        this._workspaceSwitcherPopup = Main.wm._workspaceSwitcherPopup;

                        this._signalsHandler.add(Main.wm._workspaceSwitcherPopup, 'destroy', actor => {
                            delete this._workspaceSwitcherPopup;
                            if (Main.wm._workspaceSwitcherPopup === actor)
                                delete Main.wm._workspaceSwitcherPopup;
                        });
                    }
                }
                // Set the actor non reactive, so that it doesn't prevent the
                // clicks events from reaching the dash actor. I can't see a reason
                // why it should be reactive.
                Main.wm._workspaceSwitcherPopup.reactive = false;

                // If Workspace Grid is installed, let them handle the scroll behavior.
                if (global.workspace_manager.workspace_grid !== undefined)
                    ws = global.workspace_manager.workspace_grid.actionMoveWorkspace(direction);
                else
                    Main.wm.actionMoveWorkspace(ws);

                // Do not show workspaceSwitcher in overview
                if (!Main.overview.visible)
                    Main.wm._workspaceSwitcherPopup.display(ws.index());

                return true;
            } else {
                return false;
            }
        };
    }

    _activateApp(appIndex) {
        const children = this.dash._box.get_children().filter(actor => {
            return actor.child &&
                       actor.child.app;
        });

        // Apps currently in the dash
        const apps = children.map(actor => {
            return actor.child;
        });

        // Activate with button = 1, i.e. same as left click
        const button = 1;
        if (appIndex < apps.length)
            apps[appIndex].activate(button);
    }

    /**
     * Cycle through windows of the app at the given dock position.
     *
     * @param {number} appIndex - position in the dock
     * @param {boolean} reversed - cycle backwards when true
     */
    _cycleAppWindows(appIndex, reversed) {
        const children = this.dash._box.get_children().filter(actor => {
            return actor.child &&
                       actor.child.app;
        });

        const apps = children.map(actor => {
            return actor.child;
        });

        if (appIndex < apps.length) {
            const appIcon = apps[appIndex];
            const windows = appIcon.getInterestingWindows();
            if (windows.length > 0)
                appIcon._cycleThroughWindows(reversed);
            else
                appIcon.activate(1);
        }
    }
});

/*
 * Handle keyboard shortcuts
 */
const NUM_HOTKEYS = 10;

const KeyboardShortcuts = class DashToDockKeyboardShortcuts {
    constructor() {
        this._signalsHandler = new Utils.GlobalSignalsHandler();

        this._hotKeysEnabled = false;
        this._gnomeKeysOverridden = false;
        this._savedGnomeKeys = [];

        if (DockManager.settings.hotKeys)
            this._enableHotKeys();
        else
            this._overrideGnomeKeys();


        this._signalsHandler.add([
            DockManager.settings,
            'changed::hot-keys',
            () => {
                if (DockManager.settings.hotKeys) {
                    this._restoreGnomeKeys();
                    this._enableHotKeys.bind(this)();
                } else {
                    this._disableHotKeys.bind(this)();
                    this._overrideGnomeKeys();
                }
            },
        ]);

        this._optionalNumberOverlay();
    }

    destroy() {
        DockManager.allDocks.forEach(dock => {
            if (dock._numberOverlayTimeoutId) {
                GLib.source_remove(dock._numberOverlayTimeoutId);
                delete dock._numberOverlayTimeoutId;
            }
        });

        // Remove keybindings
        this._disableHotKeys();
        this._restoreGnomeKeys();
        this._disableExtraShortcut();
        this._signalsHandler.destroy();
    }

    _overrideGnomeKeys() {
        if (this._gnomeKeysOverridden)
            return;

        // When the user disables hot-keys, GNOME Shell's built-in
        // switch-to-application-N shortcuts (Super+N) would still
        // activate favorite apps. Override them with empty bindings
        // so that Super+N truly does nothing for app activation.
        const shellSettings = new Gio.Settings({schema_id: 'org.gnome.shell.keybindings'});
        this._savedGnomeKeys = [];
        for (let i = 1; i <= 9; i++) {
            const key = `switch-to-application-${i}`;
            this._savedGnomeKeys.push({
                key,
                value: shellSettings.get_strv(key),
            });
            shellSettings.set_strv(key, []);
        }
        this._gnomeKeysOverridden = true;
    }

    _restoreGnomeKeys() {
        if (!this._gnomeKeysOverridden)
            return;

        const shellSettings = new Gio.Settings({schema_id: 'org.gnome.shell.keybindings'});
        for (const {key, value} of this._savedGnomeKeys)
            shellSettings.set_strv(key, value);

        this._savedGnomeKeys = [];
        this._gnomeKeysOverridden = false;
    }

    _enableHotKeys() {
        if (this._hotKeysEnabled)
            return;

        // Setup keyboard bindings for dash elements
        // Super+N activates the app, Super+Shift+N cycles backwards through
        // its windows, and Super+Ctrl+N opens a new window.
        const {mainDock} = DockManager.getDefault() ?? {};
        if (!mainDock)
            return;
        for (let i = 0; i < NUM_HOTKEYS; i++) {
            const appNum = i;
            Main.wm.addKeybinding(`app-hotkey-${i + 1}`, DockManager.settings,
                Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
                Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
                () => {
                    mainDock._activateApp(appNum);
                    this._showOverlay();
                });
            Main.wm.addKeybinding(`app-shift-hotkey-${i + 1}`, DockManager.settings,
                Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
                Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
                () => {
                    mainDock._cycleAppWindows(appNum, true);
                    this._showOverlay();
                });
            Main.wm.addKeybinding(`app-ctrl-hotkey-${i + 1}`, DockManager.settings,
                Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
                Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
                () => {
                    mainDock._activateApp(appNum);
                    this._showOverlay();
                });
        }

        this._hotKeysEnabled = true;
    }

    _disableHotKeys() {
        if (!this._hotKeysEnabled)
            return;

        const keys = ['app-hotkey-', 'app-shift-hotkey-', 'app-ctrl-hotkey-'];
        keys.forEach(key => {
            for (let i = 0; i < NUM_HOTKEYS; i++)
                Main.wm.removeKeybinding(key + (i + 1));
        }, this);

        this._hotKeysEnabled = false;
    }

    _optionalNumberOverlay() {
        const {settings} = DockManager;
        this._shortcutIsSet = false;
        // Enable extra shortcut if either 'overlay' or 'show-dock' are true
        if (settings.hotKeys &&
           (settings.hotkeysOverlay || settings.hotkeysShowDock))
            this._enableExtraShortcut();

        this._signalsHandler.add([
            settings,
            'changed::hot-keys',
            this._checkHotkeysOptions.bind(this),
        ], [
            settings,
            'changed::hotkeys-overlay',
            this._checkHotkeysOptions.bind(this),
        ], [
            settings,
            'changed::hotkeys-show-dock',
            this._checkHotkeysOptions.bind(this),
        ]);
    }

    _checkHotkeysOptions() {
        const {settings} = DockManager;

        if (settings.hotKeys &&
           (settings.hotkeysOverlay || settings.hotkeysShowDock))
            this._enableExtraShortcut();
        else
            this._disableExtraShortcut();
    }

    _enableExtraShortcut() {
        if (!this._shortcutIsSet) {
            Main.wm.addKeybinding('shortcut', DockManager.settings,
                Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
                Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
                this._showOverlay.bind(this));
            this._shortcutIsSet = true;
        }
    }

    _disableExtraShortcut() {
        if (this._shortcutIsSet) {
            Main.wm.removeKeybinding('shortcut');
            this._shortcutIsSet = false;
        }
    }

    _showOverlay() {
        for (const dock of DockManager.allDocks) {
            if (DockManager.settings.hotkeysOverlay)
                dock.dash.toggleNumberOverlay(true);

            // Restart the counting if the shortcut is pressed again
            if (dock._numberOverlayTimeoutId) {
                GLib.source_remove(dock._numberOverlayTimeoutId);
                dock._numberOverlayTimeoutId = 0;
            }

            // Hide the overlay/dock after the timeout
            const timeout = DockManager.settings.shortcutTimeout * 1000;
            dock._numberOverlayTimeoutId = GLib.timeout_add(
                GLib.PRIORITY_DEFAULT, timeout, () => {
                    dock._numberOverlayTimeoutId = 0;
                    dock.dash.toggleNumberOverlay(false);
                    // Hide the dock again if necessary
                    dock._updateDashVisibility();
                });

            // Show the dock if it is hidden
            if (DockManager.settings.hotkeysShowDock) {
                const showDock = dock._intellihideIsEnabled || dock._autohideIsEnabled;
                if (showDock)
                    dock._show();
            }
        }
    }
};

/**
 * Isolate overview to open new windows for inactive apps
 * Note: the future implementation is not fully contained here.
 * Some bits are around in other methods of other classes.
 * This class just take care of enabling/disabling the option.
 */
const WorkspaceIsolation = class DashToDockWorkspaceIsolation {
    constructor() {
        const {settings} = DockManager;

        this._signalsHandler = new Utils.GlobalSignalsHandler();
        this._injectionsHandler = new Utils.InjectionsHandler();

        const updateAllDocks = () => {
            DockManager.allDocks.forEach(dock =>
                dock.dash.resetAppIcons());
            if (settings.isolateWorkspaces ||
                settings.isolateMonitors)
                this._enable.bind(this)();
            else
                this._disable.bind(this)();
        };
        this._signalsHandler.add(
            [settings, 'changed::isolate-workspaces', updateAllDocks],
            [settings, 'changed::workspace-agnostic-urgent-windows', updateAllDocks],
            [settings, 'changed::isolate-monitors', updateAllDocks]
        );

        if (settings.isolateWorkspaces ||
            settings.isolateMonitors)
            this._enable();
    }

    _enable() {
        // ensure I never double-register/inject
        // although it should never happen
        this._disable();

        DockManager.allDocks.forEach(dock => {
            global.display.connectObject('restacked',
                () => dock.dash._queueRedisplay(), dock.dash);
            global.display.connectObject('window-marked-urgent',
                () => dock.dash._queueRedisplay(), dock.dash);
            global.display.connectObject('window-demands-attention',
                () => dock.dash._queueRedisplay(), dock.dash);
            global.window_manager.connectObject('switch-workspace',
                () => dock.dash._queueRedisplay(), dock.dash);

            // This last signal is only needed for monitor isolation, as windows
            // might migrate from one monitor to another without triggering 'restacked'
            if (DockManager.settings.isolateMonitors) {
                global.display.connectObject('window-entered-monitor',
                    () => dock.dash._queueRedisplay(), dock.dash);
            }
        });

        /**
         * here this is the Shell.App
         */
        function IsolatedOverview() {
            // These lines take care of Nautilus for icons on Desktop
            const activeWorkspaceIndex =
                global.workspaceManager.get_active_workspace_index();
            const windows = this.get_windows().filter(w =>
                !w.skipTaskbar && w.get_workspace().index() === activeWorkspaceIndex);

            if (windows.length)
                return Main.activateWindow(windows[0]);
            return this.open_new_window(-1);
        }

        this._injectionsHandler.addWithLabel(Labels.ISOLATION,
            Shell.App.prototype,
            'activate',
            IsolatedOverview);
    }

    _disable() {
        DockManager.allDocks.forEach(dock => {
            global.display.disconnectObject(dock.dash);
            global.window_manager.disconnectObject(dock.dash);
        });
        this._injectionsHandler.removeWithLabel(Labels.ISOLATION);
    }

    destroy() {
        this._disable();
        this._signalsHandler.destroy();
        this._injectionsHandler.destroy();
    }
};


export class DockManager {
    constructor(extension) {
        if (DockManager._singleton)
            throw new Error('DashToDock has been already initialized');
        DockManager._singleton = this;
        this._extension = extension;
        this._deferredModulesLoaded = _loadDeferredModules().catch(e =>
            logError(e, 'XDock: Failed to load deferred modules'));
        this._signalsHandler = new Utils.GlobalSignalsHandler(this);
        this._methodInjections = new Utils.InjectionsHandler(this);
        this._vfuncInjections = new Utils.VFuncInjectionsHandler(this);
        this._propertyInjections = new Utils.PropertyInjectionsHandler(this);
        this._settings = this._extension.getSettings(
            'org.gnome.shell.extensions.xdock');
        this._appSwitcherSettings = new Gio.Settings({schema_id: 'org.gnome.shell.app-switcher'});
        this._mapSettingsValues();

        this._iconTheme = new St.IconTheme();

        this._desktopIconsUsableArea = new DesktopIconsIntegration.DesktopIconsUsableAreaClass(extension);
        this._oldDash = Main.overview.isDummy ? null : Main.overview.dash;
        this._discreteGpuAvailable = AppDisplay.discreteGpuAvailable;
        this._appSpread = new AppSpread.AppSpread();
        this._notificationsMonitor = new NotificationsMonitor.NotificationsMonitor();
        this._screencastMonitor = null;
        this._mprisMonitor = null;
        this._volumeControl = null;
        this._dockProfiles = null;
        this._deferredModulesLoaded.then(() => {
            if (ScreencastMonitor)
                this._screencastMonitor = new ScreencastMonitor.ScreencastMonitor();
            if (MprisMonitor)
                this._mprisMonitor = new MprisMonitor.MprisMonitor();
            if (VolumeControl)
                this._volumeControl = new VolumeControl.VolumeControl();
            if (DockProfiles)
                this._dockProfiles = new DockProfiles.DockProfiles(this._settings);
        }).catch(e => logError(e, 'XDock: deferred module init failed'));

        const needsRemoteModel = () =>
            !this._notificationsMonitor.dndMode && this._settings.showIconsEmblems;

        const ensureRemoteModel = () => {
            const shouldHaveRemoteModel = needsRemoteModel();
            if (shouldHaveRemoteModel && !this._remoteModel) {
                this._remoteModel = new LauncherAPI.LauncherEntryRemoteModel();
                this._appIconsDecorator = new AppIconsDecorator.AppIconsDecorator();
            } else if (!shouldHaveRemoteModel) {
                this._remoteModel?.destroy();
                delete this._remoteModel;
                this._appIconsDecorator?.destroy();
                delete this._appIconsDecorator;
            }
        };
        ensureRemoteModel();

        this._signalsHandler.add(this._notificationsMonitor, 'state-changed',
            () => ensureRemoteModel());
        this._signalsHandler.add(this._settings, 'changed::show-icons-emblems',
            () => ensureRemoteModel());

        if (this._discreteGpuAvailable === undefined) {
            const updateDiscreteGpuAvailable = () => {
                const switcherooProxy = global.get_switcheroo_control();
                if (switcherooProxy) {
                    const prop = switcherooProxy.get_cached_property('HasDualGpu');
                    this._discreteGpuAvailable = prop?.unpack() ?? false;
                } else {
                    this._discreteGpuAvailable = false;
                }
            };
            this._signalsHandler.add(global, 'notify::switcheroo-control',
                () => updateDiscreteGpuAvailable());
            updateDiscreteGpuAvailable();
        }

        // Connect relevant signals to the toggling function
        this._bindSettingsChanges();

        this._ensureLocations();

        /* Array of all the docks created */
        this._allDocks = [];
        this._createDocks();

        this._overrideAppMenus();

        // status variable: true when the overview is shown through the dash
        // applications button.
        this._forcedOverview = false;

        // Wiggle mode state
        this._wiggleMode = false;
        this._wiggleEscapeCaptureId = 0;
        // Command palette
        this._commandPalette = null;
        this._commandPaletteShortcutBound = false;
        this._setupCommandPalette();
    }

    static getDefault() {
        return DockManager._singleton;
    }

    static get allDocks() {
        return DockManager.getDefault()?._allDocks ?? [];
    }

    static get extension() {
        return DockManager.getDefault()?.extension ?? null;
    }

    static get settings() {
        return DockManager.getDefault()?.settings ?? null;
    }

    get extension() {
        return this._extension;
    }

    get settings() {
        return this._settings;
    }

    static get iconTheme() {
        return DockManager.getDefault()?.iconTheme ?? null;
    }

    get settings() { // eslint-disable-line no-dupe-class-members
        return this._settings;
    }

    get iconTheme() {
        return this._iconTheme;
    }

    get fm1Client() {
        return this._fm1Client;
    }

    get remoteModel() {
        return this._remoteModel;
    }

    get mainDock() {
        return this._allDocks[0] ?? null;
    }

    get removables() {
        return this._removables;
    }

    get trash() {
        return this._trash;
    }

    get pinnedCommandsManager() {
        return this._pinnedCommandsManager;
    }

    get categoryIcons() {
        return this._categoryIcons ?? [];
    }

    // ── Wiggle Mode ─────────────────────────────────────────────────────────

    get wiggleMode() {
        return this._wiggleMode;
    }

    enterWiggleMode() {
        if (this._wiggleMode)
            return;
        if (!this._settings.wiggleModeEnabled)
            return;

        this._wiggleMode = true;
        this.emit('wiggle-mode-changed', true);

        // Grab Escape key to exit wiggle mode
        this._wiggleEscapeCaptureId = global.stage.connect('captured-event', (_actor, event) => {
            if (event.type() === Clutter.EventType.KEY_PRESS &&
                event.get_key_symbol() === Clutter.KEY_Escape) {
                this.exitWiggleMode();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        // Exit on overview show
        this._wiggleOverviewId = Main.overview.connect('showing', () => {
            this.exitWiggleMode();
        });
    }

    exitWiggleMode() {
        if (!this._wiggleMode)
            return;

        this._wiggleMode = false;
        this.emit('wiggle-mode-changed', false);

        if (this._wiggleEscapeCaptureId) {
            global.stage.disconnect(this._wiggleEscapeCaptureId);
            this._wiggleEscapeCaptureId = 0;
        }

        if (this._wiggleOverviewId) {
            Main.overview.disconnect(this._wiggleOverviewId);
            this._wiggleOverviewId = 0;
        }
    }

    get volumeControl() {
        return this._volumeControl;
    }

    // ── User-Category Management ────────────────────────────────────────────

    // ── dock-order: single authoritative order list ─────────────────────────

    getDockOrder() {
        let order = this._settings.get_strv('dock-order');
        if (order.length === 0) {
            order = this._buildInitialDockOrder();
            this._settings.set_strv('dock-order', order);
        }
        return order;
    }

    setDockOrder(order) {
        this._settings.set_strv('dock-order', order);
    }

    /** Builds dock-order on first run from legacy user-categories positions + favorites. */
    _buildInitialDockOrder() {
        const configs = this._readUserCategories();
        const catIds = new Set(configs.flatMap(c => c.apps));
        const favs = AppFavorites.getAppFavorites().getFavorites()
            .filter(a => !catIds.has(a.get_id()))
            .map(a => a.get_id());

        // Insert category IDs at their legacy position
        const order = [...favs];
        const sorted = [...configs].sort((a, b) => (a.position ?? -1) - (b.position ?? -1));
        for (const cfg of sorted) {
            const pos = cfg.position >= 0 ? Math.min(cfg.position, order.length) : order.length;
            order.splice(pos, 0, cfg.id);
        }
        return order;
    }

    /**
     * Keeps dock-order in sync after an external change to favorite-apps.
     * Only appends newly pinned favorites -- never removes entries.
     */
    _syncDockOrderWithFavorites() {
        // If any dock is currently in a DnD operation, defer the sync to
        // avoid cascading GSettings writes that freeze the compositor (#37).
        if (DockManager.allDocks.some(dock => dock.dash._dragInProgress)) {
            this._dockOrderSyncPending = true;
            return;
        }

        const order = this._settings.get_strv('dock-order');
        if (order.length === 0)
            return; // not yet migrated

        const catAppIds = new Set(this._readUserCategories().flatMap(c => c.apps));
        const validFavIds = new Set(
            AppFavorites.getAppFavorites().getFavorites()
                .filter(a => !catAppIds.has(a.get_id()))
                .map(a => a.get_id())
        );

        let changed = false;
        for (const id of validFavIds) {
            if (!order.includes(id)) {
                order.push(id);
                changed = true;
            }
        }

        if (changed)
            this._settings.set_strv('dock-order', order);
    }

    // ───────────────────────────────────────────────────────────────────────

    _readUserCategories() {
        try {
            const parsed = JSON.parse(this._settings.get_string('user-categories'));
            return Array.isArray(parsed) ? parsed : [];
        } catch {
            return [];
        }
    }

    _writeUserCategories(configs) {
        this._settings.set_string('user-categories', JSON.stringify(configs));
    }

    /**
     * Sanitizes user-categories: removes invalid entries, removes apps
     * that are simultaneously in favorite-apps from the favorites.
     */
    _repairUserCategories(configs) {
        const appSystem = Shell.AppSystem.get_default();

        const cleaned = configs
            .filter(c => c && typeof c.id === 'string' && Array.isArray(c.apps))
            .map(c => ({
                id: c.id,
                apps: c.apps.filter(a => typeof a === 'string' && appSystem.lookup_app(a) !== null),
            }))
            .filter(c => c.apps.length >= 2);

        const configsChanged = JSON.stringify(cleaned) !== JSON.stringify(configs);
        if (configsChanged)
            this._writeUserCategories(cleaned);

        // Remove from favorites any app that belongs to a category
        const categorizedIds = new Set(cleaned.flatMap(c => c.apps));
        if (categorizedIds.size > 0) {
            const favs = AppFavorites.getAppFavorites();
            const favMap = favs.getFavoriteMap();
            for (const appId of categorizedIds) {
                if (appId in favMap)
                    favs.removeFavorite(appId);
            }
        }

        return cleaned;
    }

    /**
     * Creates a new category with two apps at the given dock position.
     */
    createUserCategory(appId1, appId2, dockInsertIdx) {
        const newId = Locations.generateCategoryId();
        const configs = this._readUserCategories();
        configs.push({id: newId, apps: [appId1, appId2]});
        this._writeUserCategories(configs);

        // Update dock-order: remove the two app IDs, insert the category ID
        const order = this.getDockOrder();
        const filtered = order.filter(id => id !== appId1 && id !== appId2);
        const insertAt = dockInsertIdx != null
            ? Math.min(dockInsertIdx, filtered.length)
            : filtered.length;
        filtered.splice(insertAt, 0, newId);
        this.setDockOrder(filtered);
    }

    /**
     * Adds an app to an existing category (if not already present).
     */
    addAppToUserCategory(categoryId, appId) {
        const configs = this._readUserCategories();
        const cat = configs.find(c => c.id === categoryId);
        if (!cat)
            return;
        if (!cat.apps.includes(appId))
            cat.apps.push(appId);
        this._writeUserCategories(configs);
    }

    /**
     * Removes an app from a category.
     * If the category then has < 2 apps, it is dissolved:
     *   - the remaining app is inserted as a favorite at the category position.
     *   - the category is deleted.
     * Returns whether the category was dissolved.
     */
    removeAppFromUserCategory(categoryId, appId) {
        const configs = this._readUserCategories();
        const idx = configs.findIndex(c => c.id === categoryId);
        if (idx < 0)
            return false;

        const cat = configs[idx];
        cat.apps = cat.apps.filter(id => id !== appId);

        if (cat.apps.length < 2) {
            // Dissolve category
            const remaining = cat.apps[0] ?? null;
            configs.splice(idx, 1);
            this._writeUserCategories(configs);

            // dock-order: replace category ID with remaining app ID (or just remove)
            const order = this._settings.get_strv('dock-order');
            if (order.length > 0) {
                const catPos = order.indexOf(categoryId);
                if (catPos >= 0) {
                    if (remaining)
                        order.splice(catPos, 1, remaining);
                    else
                        order.splice(catPos, 1);
                    this._settings.set_strv('dock-order', order);
                }
            }

            if (remaining) {
                const favs = AppFavorites.getAppFavorites();
                if (!(remaining in favs.getFavoriteMap())) {
                    const newOrder = this._settings.get_strv('dock-order');
                    const catAppIds = new Set(configs.flatMap(c => c.apps));
                    let favPos = 0;
                    for (const id of newOrder) {
                        if (id === remaining)
                            break;
                        if (!new Set(configs.map(c => c.id)).has(id) && !catAppIds.has(id))
                            favPos++;
                    }
                    favs.addFavoriteAtPos(remaining, favPos);
                }
            }
            return true;
        }

        this._writeUserCategories(configs);
        return false;
    }

    /**
     * Merges two categories -- apps from the source category are moved
     * to the target category, the source category is deleted.
     */
    mergeUserCategories(sourceCategoryId, targetCategoryId) {
        if (sourceCategoryId === targetCategoryId)
            return;
        const configs = this._readUserCategories();
        const src = configs.find(c => c.id === sourceCategoryId);
        const tgt = configs.find(c => c.id === targetCategoryId);
        if (!src || !tgt)
            return;

        for (const appId of src.apps) {
            if (!tgt.apps.includes(appId))
                tgt.apps.push(appId);
        }

        configs.splice(configs.indexOf(src), 1);
        this._writeUserCategories(configs);

        // Remove source category ID from dock-order
        const order = this._settings.get_strv('dock-order');
        const pos = order.indexOf(sourceCategoryId);
        if (pos >= 0) {
            order.splice(pos, 1);
            this._settings.set_strv('dock-order', order);
        }
    }

    /**
     * Returns all app IDs that belong to a user category.
     */
    getCategorizedAppIds() {
        return new Set(this._readUserCategories().flatMap(c => c.apps));
    }

    // ───────────────────────────────────────────────────────────────────────

    get desktopIconsUsableArea() {
        return this._desktopIconsUsableArea;
    }

    get discreteGpuAvailable() {
        return AppDisplay.discreteGpuAvailable || this._discreteGpuAvailable;
    }

    get appSpread() {
        return this._appSpread;
    }

    get notificationsMonitor() {
        return this._notificationsMonitor;
    }

    get screencastMonitor() {
        return this._screencastMonitor;
    }

    get mprisMonitor() {
        return this._mprisMonitor;
    }

    get dockProfiles() {
        return this._dockProfiles;
    }

    getDockByMonitor(monitorIndex) {
        return this._allDocks.find(d => d.monitorIndex === monitorIndex);
    }

    _ensureLocations() {
        const {showMounts, showTrash} = this.settings;

        if (showTrash || showMounts) {
            if (!this._fm1Client)
                this._fm1Client = new FileManager1API.FileManager1Client();
        } else if (this._fm1Client) {
            this._fm1Client.destroy();
            this._fm1Client = null;
        }

        if (showMounts && !this._removables) {
            this._removables = new Locations.Removables();
        } else if (!showMounts && this._removables) {
            this._removables.destroy();
            this._removables = null;
        }

        if (showTrash && !this._trash) {
            this._trash = new Locations.Trash();
        } else if (!showTrash && this._trash) {
            this._trash.destroy();
            this._trash = null;
        }

        // ── User Category Icons ─────────────────────────────────────
        if (!this._categoryIcons)
            this._categoryIcons = [];

        let configs = [];
        try {
            configs = JSON.parse(this._settings.get_string('user-categories'));
        } catch { /* invalid JSON in settings, use empty default */ }
        if (!Array.isArray(configs))
            configs = [];

        // Self-repair: sanitize configs and remove cross-contamination with favorites
        configs = this._repairUserCategories(configs);

        // Destroy surplus icons
        while (this._categoryIcons.length > configs.length)
            this._categoryIcons.pop().destroy();

        // Update existing / create new
        for (let i = 0; i < configs.length; i++) {
            if (this._categoryIcons[i])
                this._categoryIcons[i].updateConfig(configs[i]);
            else
                this._categoryIcons[i] = new Locations.CategoryIcon(configs[i]);
        }
        // ───────────────────────────────────────────────────────────

        // ── Pinned Commands ─────────────────────────────────────────
        if (this.settings.showPinnedCommands) {
            if (!this._pinnedCommandsManager && PinnedCommands)
                this._pinnedCommandsManager = new PinnedCommands.PinnedCommandsManager();
        } else if (this._pinnedCommandsManager) {
            this._pinnedCommandsManager.destroy();
            this._pinnedCommandsManager = null;
        }
        // ───────────────────────────────────────────────────────────

        Locations.unWrapFileManagerApp();
        [this._methodInjections, this._propertyInjections].forEach(
            injections => injections.removeWithLabel(Labels.LOCATIONS));

        if (showMounts || showTrash) {
            if (this.settings.isolateLocations) {
                const fileManagerApp = Locations.wrapFileManagerApp();

                this._methodInjections.addWithLabel(Labels.LOCATIONS, [
                    Shell.AppSystem.prototype, 'get_running',
                    function (originalMethod, ...args) {
                        /* eslint-disable no-invalid-this */
                        const runningApps = originalMethod.call(this, ...args);
                        const locationApps = Locations.getRunningApps();
                        if (!locationApps.length)
                            return runningApps;

                        const fileManagerIdx = runningApps.indexOf(fileManagerApp);
                        if (fileManagerIdx > -1 && fileManagerApp?.state !== Shell.AppState.RUNNING)
                            runningApps.splice(fileManagerIdx, 1);

                        return [...runningApps, ...locationApps].sort(Utils.shellAppCompare);
                        /* eslint-enable no-invalid-this */
                    },
                ],
                [
                    Shell.WindowTracker.prototype, 'get_window_app',
                    function (originalMethod, window) {
                        /* eslint-disable no-invalid-this */
                        const locationApp = Locations.getRunningApps().find(a =>
                            a.get_windows().includes(window));
                        return locationApp ?? originalMethod.call(this, window);
                        /* eslint-enable no-invalid-this */
                    },
                ],
                [
                    Shell.WindowTracker.prototype, 'get_app_from_pid',
                    function (originalMethod, pid) {
                        /* eslint-disable no-invalid-this */
                        const locationApp = Locations.getRunningApps().find(a =>
                            a.get_pids().includes(pid));
                        return locationApp ?? originalMethod.call(this, pid);
                        /* eslint-enable no-invalid-this */
                    },
                ]);

                const {get: defaultFocusAppGetter} = Object.getOwnPropertyDescriptor(
                    Shell.WindowTracker.prototype, 'focus_app');
                this._propertyInjections.addWithLabel(Labels.LOCATIONS,
                    Shell.WindowTracker.prototype, 'focus_app', {
                        get() {
                            const locationApp = Locations.getRunningApps().find(a => a.isFocused);
                            return locationApp ?? defaultFocusAppGetter.call(this);
                        },
                    });
            }
        }
    }

    // ── Command Palette ──────────────────────────────────────────────────

    _setupCommandPalette() {
        this._signalsHandler.add(this._settings, 'changed::command-palette-enabled',
            () => this._updateCommandPaletteBinding());
        this._signalsHandler.add(this._settings, 'changed::command-palette-shortcut',
            () => this._updateCommandPaletteBinding());

        this._updateCommandPaletteBinding();
    }

    _updateCommandPaletteBinding() {
        // Remove old binding if any
        if (this._commandPaletteShortcutBound) {
            Main.wm.removeKeybinding('command-palette-shortcut');
            this._commandPaletteShortcutBound = false;
        }

        if (!this._settings.commandPaletteEnabled)
            return;

        // Bind the shortcut
        Main.wm.addKeybinding('command-palette-shortcut', this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
            () => this.toggleCommandPalette());
        this._commandPaletteShortcutBound = true;
    }

    toggleCommandPalette() {
        if (!CommandPalette)
            return;
        if (!this._commandPalette) {
            this._commandPalette = new CommandPalette.CommandPalette();
            Main.uiGroup.add_child(this._commandPalette);
        }

        this._commandPalette.toggle();
    }

    _destroyCommandPalette() {
        if (this._commandPaletteShortcutBound) {
            Main.wm.removeKeybinding('command-palette-shortcut');
            this._commandPaletteShortcutBound = false;
        }

        if (this._commandPalette) {
            this._commandPalette.destroy();
            this._commandPalette = null;
        }
    }

    // ───────────────────────────────────────────────────────────────────────

    _toggle() {
        if (this._toggleLater)
            return;

        this._toggleLater = Utils.laterAdd(Meta.LaterType.BEFORE_REDRAW, () => {
            delete this._toggleLater;
            this._restoreDash();
            this._deleteDocks();
            this._createDocks();
            this.emit('toggled');
        });
    }

    _mapExternalSetting(settings, key, mappedKey, mapValueFunction) {
        const camelMappedKey = mappedKey.replace(/-([a-z\d])/g, k => k[1].toUpperCase());

        const dockPropertyDesc = Object.getOwnPropertyDescriptor(this.settings, camelMappedKey);

        if (!dockPropertyDesc)
            throw new Error('Setting %s not found in dock'.format(mappedKey));

        const mappedValue = () => mapValueFunction(settings.get_value(key).recursiveUnpack());
        Object.defineProperty(this.settings, camelMappedKey, {
            get: () => mappedValue() ?? dockPropertyDesc.value,
            set: value => {
                if (mappedValue())
                    dockPropertyDesc.value = value;
            },
        });

        this._signalsHandler.addWithLabel(Labels.SETTINGS, settings,
            'changed::%s'.format(key), () => {
                this._signalsHandler.blockWithLabel(Labels.SETTINGS);
                this.settings.emit('changed::%s'.format(mappedKey), mappedKey);
                this._signalsHandler.unblockWithLabel(Labels.SETTINGS);
            });
    }

    _mapSettingsValues() {
        this.settings.settingsSchema.list_keys().forEach(key => {
            const camelKey = key.replace(/-([a-z\d])/g, k => k[1].toUpperCase());
            const updateSetting = () => {
                const schemaKey = this.settings.settingsSchema.get_key(key);
                if (schemaKey.get_range().deepUnpack()[0] === 'enum')
                    this.settings[camelKey] = this.settings.get_enum(key);
                else
                    this.settings[camelKey] = this.settings.get_value(key).recursiveUnpack();
            };
            updateSetting();
            this._signalsHandler.addWithLabel(Labels.SETTINGS, this.settings,
                `changed::${key}`, updateSetting);
            if (key !== camelKey) {
                Object.defineProperty(this.settings, key,
                    {get: () => this.settings[camelKey]});
            }
        });
        Object.defineProperties(this.settings, {
            dockExtended: {get: () => this.settings.extendHeight},
        });
    }

    _bindSettingsChanges() {
        // Connect relevant signals to the toggling function
        this._signalsHandler.addWithLabel(Labels.SETTINGS, [
            Utils.getMonitorManager(),
            'monitors-changed',
            this._toggle.bind(this),
        ], [
            Main.sessionMode,
            'updated',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::multi-monitor',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::monitor-positions',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::preferred-monitor-by-connector',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::dock-position',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::secondary-dock-enabled',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::secondary-dock-position',
            this._toggle.bind(this),
        ], [
            this._settings,
            'changed::extend-height',
            () => this._adjustPanelCorners(),
        ], [
            this._settings,
            'changed::dock-fixed',
            () => this._adjustPanelCorners(),
        ], [
            this._settings,
            'changed::show-trash',
            () => this._ensureLocations(),
        ], [
            this._settings,
            'changed::show-mounts',
            () => this._ensureLocations(),
        ], [
            this._settings,
            'changed::isolate-locations',
            () => this._ensureLocations(),
        ], [
            this._settings,
            'changed::user-categories',
            () => {
                // If a DnD is in progress, defer this heavy operation until
                // the drag completes to prevent compositor freezes (#37).
                if (DockManager.allDocks.some(dock => dock.dash._dragInProgress)) {
                    this._ensureLocationsPending = true;
                    DockManager.allDocks.forEach(dock => {
                        dock.dash._resetIconsQueuedDuringDrag = true;
                    });
                    return;
                }
                this._ensureLocations();
                DockManager.allDocks.forEach(dock => dock.dash._queueRedisplay());
            },
        ], [
            this._settings,
            'changed::show-pinned-commands',
            () => {
                this._ensureLocations();
                DockManager.allDocks.forEach(dock => dock.dash.resetAppIcons());
            },
        ], [
            this._settings,
            'changed::pinned-commands',
            () => {
                DockManager.allDocks.forEach(dock => dock.dash._queueRedisplay());
            },
        ], [
            AppFavorites.getAppFavorites(),
            'changed',
            () => this._syncDockOrderWithFavorites(),
        ], [
            this._settings,
            'changed::intellihide',
            () => {
                if (!this._settings.intellihide)
                    this._desktopIconsUsableArea.resetMargins();
            },
        ], [
            this._settings,
            'changed::dock-tiling-enabled',
            () => this._ensureDockTiling(),
        ]);

        this._mapExternalSetting(this._appSwitcherSettings, 'current-workspace-only',
            'isolate-workspaces', value => value || undefined);
    }

    _createDocks() {
        // If there are no monitors (headless configurations, but it can also
        // happen temporary while disconnecting and reconnecting monitors), just
        // do nothing. When a monitor will be connected we we'll be notified and
        // and thus create the docks. This prevents pointing trying to access
        // monitors throughout the code, were we are assuming that at least the
        // primary monitor is present.
        if (Main.layoutManager.monitors.length <= 0)
            return;


        const monitorManager = Utils.getMonitorManager();
        this._preferredMonitorIndex = monitorManager.get_monitor_for_connector(
            this.settings.preferredMonitorByConnector);

        // In case of multi-monitor, we consider the dock on the primary monitor
        // to be the preferred (main) one regardless of the settings the dock
        // goes on the primary monitor also if the settings are inconsistent
        // (e.g. desired monitor not connected).
        if (this.settings.multiMonitor ||
            this._preferredMonitorIndex < 0 ||
            this._preferredMonitorIndex > Main.layoutManager.monitors.length - 1)
            this._preferredMonitorIndex = Main.layoutManager.primaryIndex;


        // First we create the main Dock, to get the extra features to bind to this one
        this._createDock({
            monitorIndex: this._preferredMonitorIndex,
            isMain: true,
        });

        // Make the necessary changes to Main.overview.dash
        this._prepareMainDash();

        // In devkit/headless sessions, the startup animation may have
        // crashed before monitors were available, leaving the overview
        // stuck open. Complete startup and dismiss the overview.
        if (Main.layoutManager._startingUp) {
            if (Main.layoutManager._coverPane)
                Main.layoutManager._startupAnimationComplete();
            else
                Main.layoutManager._startingUp = false;
        }

        // Adjust corners if necessary
        this._adjustPanelCorners();

        if (this.settings.multiMonitor) {
            const nMon = Main.layoutManager.monitors.length;
            for (let iMon = 0; iMon < nMon; iMon++) {
                if (iMon === this._preferredMonitorIndex)
                    continue;

                this._createDock({monitorIndex: iMon});
            }
        }

        // Create secondary dock on a different edge if enabled
        if (this.settings.secondaryDockEnabled) {
            const secondaryPosition = Utils.getSecondaryPosition();
            const primaryPosition = Utils.getPosition(this._preferredMonitorIndex);
            // Only create if positions differ
            if (secondaryPosition !== primaryPosition) {
                this._createDock({
                    monitorIndex: this._preferredMonitorIndex,
                    is_secondary: true,
                });
            }
        }

        // Load optional features. We load *after* the docks are created, since
        // we need to connect the signals to all dock instances.
        this._workspaceIsolation = new WorkspaceIsolation();
        this._keyboardShortcuts = new KeyboardShortcuts();

        // Window tiling from dock drag
        this._ensureDockTiling();

        this.emit('docks-ready');
    }

    _createDock(params) {
        const dock = new DockedDash(params);
        this._allDocks.push(dock);

        // connect app icon into the view selector
        dock.dash.showAppsButton.connectObject('notify::checked',
            button => this._onShowAppsButtonToggled(button), dock);

        const id = dock.connect('destroy', () => {
            dock.disconnect(id);
            const index = this._allDocks.indexOf(dock);
            if (index !== -1)
                this._allDocks.splice(index, 1);
        });

        return dock;
    }

    _prepareStartupAnimation() {
        DockManager.allDocks.forEach(dock => {
            const {dash} = dock;

            dock.opacity = 255;
            dash.set({
                opacity: 0,
                translation_x: 0,
                translation_y: 0,
            });
        });
    }

    _runStartupAnimation() {
        DockManager.allDocks.forEach(dock => {
            const {dash} = dock;

            switch (dock.position) {
            case St.Side.LEFT:
                dash.translation_x = -dash.width;
                break;
            case St.Side.RIGHT:
                dash.translation_x = dash.width;
                break;
            case St.Side.BOTTOM:
                dash.translation_y = dash.height;
                break;
            case St.Side.TOP:
                dash.translation_y = -dash.height;
                break;
            }

            dash.ease({
                opacity: 255,
                translation_x: 0,
                translation_y: 0,
                duration: DockManager.settings.startupAnimationTime ?? STARTUP_ANIMATION_TIME,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD,
            });
        });
    }

    _prepareMainDash() {
        this._propertyInjections.removeWithLabel(Labels.MAIN_DASH);

        // Ensure Main.overview.dash is set to our dash in dummy mode
        // while just use the default getter otherwise.
        if (Main.overview.isDummy) {
            this._propertyInjections.addWithLabel(Labels.MAIN_DASH, Main.overview, 'dash', {
                get: () => this.mainDock.dash,
            });

            return;
        }

        // Hide usual Dash
        this._oldDash.hide();

        // Also set dash width to 1, so it's almost not taken into account by code
        // calculating the reserved space in the overview. The reason to keep it at 1 is
        // to allow its visibility change to trigger an allocation of the appGrid which
        // in turn is triggering the appsIcon spring animation, required when no other
        // actors has this effect, i.e in horizontal mode and without the workspaceThumbnails
        // 1 static workspace only)
        this._oldDash.set_height(1);

        this._signalsHandler.addWithLabel(Labels.OLD_DASH_CHANGES, [
            this._oldDash,
            'notify::visible',
            () => this._oldDash.hide(),
        ], [
            this._oldDash,
            'notify::height',
            () => this._oldDash.set_height(1),
        ]);

        // Pretend I'm the dash: meant to make app grid swarm animation come from
        // the right position of the appShowButton.
        const replaceMainDash = () => {
            this.overviewControls.dash = this.mainDock.dash;
            this.searchController._showAppsButton = this.mainDock.dash.showAppsButton;
        };

        // We also need to ignore max-size changes
        this._methodInjections.addWithLabel(Labels.MAIN_DASH, this._oldDash,
            'setMaxSize', () => {});
        this._methodInjections.addWithLabel(Labels.MAIN_DASH, this._oldDash,
            'allocate', () => {});
        // And to return the preferred height depending on the state
        this._methodInjections.addWithLabel(Labels.MAIN_DASH, this._oldDash,
            'get_preferred_height', (_originalMethod, ...args) => {
                if (this.mainDock.isHorizontal && !this.settings.dockFixed)
                    return this.mainDock.get_preferred_height(...args);
                return [0, 0];
            });

        // FIXME: https://gitlab.gnome.org/GNOME/gnome-shell/-/merge_requests/2890
        // const { ControlsManagerLayout } = OverviewControls;
        const ControlsManagerLayout = this.overviewControls.layout_manager.constructor;

        const maybeAdjustBoxSize = (state, box, _spacing) => {
            if (state === OverviewControls.ControlsState.WINDOW_PICKER) {
                // Account for horizontal dock height so that window preview
                // tooltips in the overview are not cropped by the dock (#2530).
                //
                // The search entry height and spacing are already subtracted
                // by the original _computeWorkspacesBoxForState, so we must
                // NOT subtract them again here.  The previous code subtracted
                // searchBox.get_height() + 2*spacing (plus extra spacing
                // adjustments when thumbnails were hidden), which double-
                // counted the search entry and shrank the workspace area
                // enough to hide the empty "new workspace" that GNOME shows
                // at the end when dynamic workspaces are enabled (#40).
                if (this.mainDock.isHorizontal && !this.settings.dockFixed) {
                    const [, preferredHeight] = this.mainDock.get_preferred_height(
                        box.get_width());
                    if (this.mainDock.position === St.Side.BOTTOM)
                        box.y2 -= preferredHeight;
                    else if (this.mainDock.position === St.Side.TOP)
                        box.y1 += preferredHeight;
                }
            }

            return box;
        };

        const maybeAdjustBoxToDock = (state, box, spacing) => {
            maybeAdjustBoxSize(state, box, spacing);

            if (this.mainDock.isHorizontal || this.settings.dockFixed)
                return box;

            const [, preferredWidth] = this.mainDock.get_preferred_width(
                box.get_height());

            if (this.mainDock.position === St.Side.LEFT)
                box.x1 += preferredWidth;
            else if (this.mainDock.position === St.Side.RIGHT)
                box.x2 -= preferredWidth;

            return box;
        };

        this._vfuncInjections.addWithLabel(Labels.MAIN_DASH, ControlsManagerLayout.prototype,
            'allocate', function (container) {
                /* eslint-disable no-invalid-this */
                const oldPostAllocation = this._runPostAllocation;
                this._runPostAllocation = () => {};

                const monitor = Main.layoutManager.findMonitorForActor(container);
                const workArea = Main.layoutManager.getWorkAreaForMonitor(monitor.index);
                const startX = workArea.x - monitor.x;
                const startY = workArea.y - monitor.y;
                const workAreaBox = new Clutter.ActorBox();
                workAreaBox.set_origin(startX, startY);
                workAreaBox.set_size(workArea.width, workArea.height);

                const spacing = this._spacing;

                maybeAdjustBoxToDock(undefined, workAreaBox, spacing);
                const oldStartY = workAreaBox.y1;

                const propertyInjections = new Utils.PropertyInjectionsHandler();
                propertyInjections.add(Main.layoutManager.panelBox, 'height', {value: startY});

                if (Main.layoutManager.panelBox.y === Main.layoutManager.primaryMonitor.y)
                    workAreaBox.y1 -= oldStartY;

                this.vfunc_allocate(container, workAreaBox);

                propertyInjections.destroy();
                workAreaBox.y1 = oldStartY;

                const adjustActorHorizontalAllocation = actor => {
                    if (!actor.visible || !workAreaBox.x1)
                        return;

                    const contentBox = actor.get_allocation_box();
                    contentBox.set_size(workAreaBox.get_width(), contentBox.get_height());
                    contentBox.set_origin(workAreaBox.x1, contentBox.y1);
                    actor.allocate(contentBox);
                };

                [this._searchEntry, this._workspacesThumbnails, this._searchController].forEach(
                    actor => adjustActorHorizontalAllocation(actor));

                this._runPostAllocation = oldPostAllocation;
                this._runPostAllocation();
                /* eslint-enable no-invalid-this */
            });

        /**
         * This can be removed or bypassed when GNOME/gnome-shell!1892 will be merged
         *
         * @param originalFunction
         * @param state
         * @param workAreaBox
         * @param {...any} args
         */
        function workspaceBoxOriginFixer(originalFunction, state, workAreaBox, ...args) {
            /* eslint-disable no-invalid-this */
            const workspaceBox = originalFunction.call(this, state, workAreaBox, ...args);
            workspaceBox.set_origin(workAreaBox.x1, workspaceBox.y1);
            return workspaceBox;
            /* eslint-enable no-invalid-this */
        }

        this._methodInjections.addWithLabel(Labels.MAIN_DASH, [
            ControlsManagerLayout.prototype,
            '_computeWorkspacesBoxForState',
            function (originalFunction, state, ...args) {
                /* eslint-disable no-invalid-this */
                if (state === OverviewControls.ControlsState.HIDDEN)
                    return originalFunction.call(this, state, ...args);

                const box = workspaceBoxOriginFixer.call(this, originalFunction, state, ...args);
                const spacing = this._spacing;
                const dock = DockManager.getDefault()?.getDockByMonitor(Main.layoutManager.primaryIndex);
                if (!dock)
                    return box;
                else
                    return maybeAdjustBoxSize(state, box, spacing);
                /* eslint-enable no-invalid-this */
            },
        ], [
            WorkspacesView.SecondaryMonitorDisplay.prototype,
            '_getWorkspacesBoxForState',
            function (originalFunction, state, ...args) {
                /* eslint-disable no-invalid-this */
                if (state === OverviewControls.ControlsState.HIDDEN)
                    return originalFunction.call(this, state, ...args);

                const box = workspaceBoxOriginFixer.call(this, originalFunction, state, ...args);
                const dock = DockManager.getDefault()?.getDockByMonitor(this._monitorIndex);
                if (!dock)
                    return box;
                if (state === OverviewControls.ControlsState.WINDOW_PICKER &&
                    dock.position === St.Side.BOTTOM) {
                    const [, preferredHeight] = dock.get_preferred_height(box.get_width());
                    box.y2 -= preferredHeight;
                }
                return box;
                /* eslint-enable no-invalid-this */
            },
        ], [
            ControlsManagerLayout.prototype,
            '_getAppDisplayBoxForState',
            function (originalFunction, state, box, ...args) {
                /* eslint-disable no-invalid-this */
                const appDisplayBox = originalFunction.call(this, state, box, ...args);

                // The app grid should use the full available width, not the
                // dock-reduced width.  The box passed to vfunc_allocate has
                // already been shrunk by maybeAdjustBoxToDock for vertical
                // auto-hide docks, so the original function computes a
                // narrower app grid.  Undo that shrinkage here so the
                // app-grid icons fill the whole screen width.
                const dockManager = DockManager.getDefault();
                const dock = dockManager?.mainDock;
                if (dock && !dock.isHorizontal && !dockManager.settings.dockFixed) {
                    const [, preferredWidth] = dock.get_preferred_width(
                        box.get_height());

                    // Restore the full width regardless of dock side.
                    // For LEFT docks box.x1 was increased, for RIGHT docks
                    // box.x2 was decreased — either way the width shrank by
                    // preferredWidth.  The app grid origin should stay at 0.
                    const fullWidth = appDisplayBox.get_width() + preferredWidth;
                    appDisplayBox.set_origin(0, appDisplayBox.y1);
                    appDisplayBox.set_size(fullWidth, appDisplayBox.get_height());
                } else {
                    appDisplayBox.set_origin(box.x1, appDisplayBox.y1);
                }

                return appDisplayBox;
                /* eslint-enable no-invalid-this */
            },
        ], [
            // Sadly CtrlAltTabPopup is not exported, so we cannot just patch it.
            SwitcherPopup.SwitcherPopup.prototype,
            '_finish',
            function (originalFunction, ...args) {
                /* eslint-disable no-invalid-this */
                if (this.constructor.name === 'CtrlAltTabPopup') {
                    const dockManager = DockManager.getDefault();
                    if (!dockManager || dockManager._inCtrlAltTabSwitcher)
                        return;

                    dockManager._inCtrlAltTabSwitcher = true;
                    this.constructor.prototype._finish.call(this, ...args);
                    delete dockManager._inCtrlAltTabSwitcher;
                }
                originalFunction.call(this, ...args);
                /* eslint-enable no-invalid-this */
            },
        ]);

        this._vfuncInjections.addWithLabel(Labels.MAIN_DASH, Workspace.WorkspaceBackground.prototype,
            'allocate', function (box) {
                /* eslint-disable no-invalid-this */
                this.vfunc_allocate(box);

                // This code has been submitted upstream via GNOME/gnome-shell!1892
                // so can be removed when that gets merged (or bypassed on newer shell
                // versions).
                const monitor = Main.layoutManager.monitors[this._monitorIndex];
                const [contentWidth, contentHeight] = this._bin.get_content_box().get_size();
                const [mX1, mX2] = [monitor.x, monitor.x + monitor.width];
                const [mY1, mY2] = [monitor.y, monitor.y + monitor.height];
                const [wX1, wX2] = [this._workarea.x, this._workarea.x + this._workarea.width];
                const [wY1, wY2] = [this._workarea.y, this._workarea.y + this._workarea.height];
                const xScale = contentWidth / this._workarea.width;
                const yScale = contentHeight / this._workarea.height;
                const leftOffset = wX1 - mX1;
                const topOffset = wY1 - mY1;
                const rightOffset = mX2 - wX2;
                const bottomOffset = mY2 - wY2;

                const contentBox = new Clutter.ActorBox();
                contentBox.set_origin(-leftOffset * xScale, -topOffset * yScale);
                contentBox.set_size(
                    contentWidth + (leftOffset + rightOffset) * xScale,
                    contentHeight + (topOffset + bottomOffset) * yScale);

                this._backgroundGroup.allocate(contentBox);
                /* eslint-enable no-invalid-this */
            });

        // Reduce the space that the workspaces can use in secondary monitors
        this._methodInjections.addWithLabel(Labels.MAIN_DASH, WorkspacesView.WorkspacesView.prototype,
            '_getFirstFitAllWorkspaceBox', function (originalFunction, ...args) {
                /* eslint-disable no-invalid-this */
                const box = originalFunction.call(this, ...args);
                if (DockManager.settings.dockFixed ||
                    this._monitorIndex === Main.layoutManager.primaryIndex)
                    return box;

                const dock = DockManager.getDefault()?.getDockByMonitor(this._monitorIndex);
                if (!dock)
                    return box;

                if (dock.isHorizontal) {
                    const [, preferredHeight] = dock.get_preferred_height(box.get_width());
                    box.y2 -= preferredHeight;
                    if (dock.position === St.Side.TOP)
                        box.set_origin(box.x1, box.y1 + preferredHeight);
                } else {
                    const [, preferredWidth] = dock.get_preferred_width(box.get_height());
                    box.x2 -= preferredWidth / 2;
                    if (dock.position === St.Side.LEFT)
                        box.set_origin(box.x1 + preferredWidth, box.y1);
                }
                return box;
                /* eslint-enable no-invalid-this */
            });

        if (Main.layoutManager._startingUp) {
            this._prepareStartupAnimation();

            const hadOverview = Main.sessionMode.hasOverview;

            if (this._settings.disableOverviewOnStartup) {
                // Tell LayoutManager to skip the overview startup animation
                // entirely. In GNOME 50+ _startupAnimationSession() is async
                // and checks hasOverview to decide whether to run the overview
                // entrance animation.  Setting it to false makes it use the
                // simple scale/fade path instead, which never opens the overview.
                Main.sessionMode.hasOverview = false;

                // Legacy fallback (GNOME < 50): inject a property override on
                // OverviewAdjustment.prototype.value so the adjustment always
                // reports HIDDEN during startup.  In GNOME 50+ `value` is a
                // native GObject property on St.Adjustment, so this override is
                // ineffective — the hasOverview=false approach above is the
                // primary mechanism.
                const {OverviewAdjustment} = OverviewControls;
                this._propertyInjections.addWithLabel(Labels.STARTUP_ANIMATION,
                    OverviewAdjustment.prototype, 'value', {
                        get: () => OverviewControls.ControlsState.HIDDEN,
                    });
            }

            // Use a dummy actor as dash during the startup animation, until
            // we're done with it, so that nothing is really shown or modified
            // during the upstream startup animation, that still requires to
            // have a valid actor.
            const dummyDash = new Clutter.Actor({visible: false, opacity: 0});
            this.overviewControls.dash = dummyDash;
            Main.uiGroup.add_child(dummyDash);

            this._signalsHandler.addWithLabel(Labels.STARTUP_ANIMATION,
                Main.layoutManager, 'startup-complete', () => {
                    this._signalsHandler.removeWithLabel(Labels.STARTUP_ANIMATION);
                    Main.sessionMode.hasOverview = hadOverview;
                    replaceMainDash();
                    dummyDash.destroy();
                    this._runStartupAnimation();
                    if (this._settings.disableOverviewOnStartup) {
                        this._propertyInjections.removeWithLabel(Labels.STARTUP_ANIMATION);

                        // Force the overview closed if it is still visible.
                        // In GNOME 50+ the async startup animation may have
                        // already shown the overview before our hasOverview
                        // override took effect (race with extension load
                        // timing).  Calling hide() is safe even if the
                        // overview is already hidden.
                        if (Main.overview.visible)
                            Main.overview.hide();

                        // Guard: only reset state if overview is not currently
                        // in a transition (SHOWING/HIDING) to avoid invalid
                        // state machine transitions (SHOWING -> SHOWING).
                        const adj = Main.overview._overview?.controls?._stateAdjustment;
                        if (adj && !Main.overview.animationInProgress)
                            adj.value = OverviewControls.ControlsState.HIDDEN;
                    }
                });
        } else {
            replaceMainDash();

            // Extension loaded after startup completed — if overview is
            // still visible and the user has disabled it, close it now.
            if (this._settings.disableOverviewOnStartup &&
                Main.overview.visible)
                Main.overview.hide();
        }
    }

    _ensureDockTiling() {
        if (this._settings.dockTilingEnabled) {
            if (!this._dockTiling && DockTiling)
                this._dockTiling = new DockTiling.DockTiling();
        } else if (this._dockTiling) {
            this._dockTiling.destroy();
            this._dockTiling = null;
        }
    }

    _deleteDocks() {
        // Remove extra features
        this._workspaceIsolation?.destroy();
        this._keyboardShortcuts?.destroy();
        this._dockTiling?.destroy();
        this._dockTiling = null;
        this._desktopIconsUsableArea?.resetMargins();

        // Delete all docks
        [...this._allDocks].forEach(d => d.destroy());

        this.emit('docks-destroyed');
    }

    _restoreDash() {
        if (!this._oldDash || this.overviewControls.dash === this._oldDash)
            return;

        this._signalsHandler.removeWithLabel(Labels.OLD_DASH_CHANGES);
        [this._methodInjections, this._vfuncInjections, this._propertyInjections].forEach(
            injections => injections.removeWithLabel(Labels.MAIN_DASH));

        this.overviewControls.layout_manager._dash = this._oldDash;
        this.overviewControls.dash = this._oldDash;
        this.searchController._showAppsButton = this._oldDash.showAppsButton;
        Main.overview.dash.show();
        Main.overview.dash.set_height(-1); // reset default dash size
        // This force the recalculation of the icon size
        Main.overview.dash._maxHeight = -1;
    }

    get overviewControls() {
        return Main.overview._overview.controls;
    }

    get searchController() {
        return this.overviewControls._searchController;
    }

    _onShowAppsButtonToggled(button) {
        const {checked} = button;
        const {overviewControls} = this;
        const adj = overviewControls._stateAdjustment;

        // When a touchpad gesture is driving the overview transition (e.g. 3-finger
        // swipe), the upstream gestureEnd() sets showAppsButton.checked to sync
        // with the target state and starts its own ease animation. We must not
        // interfere by calling Main.overview.show()/hide() or starting a
        // competing state transition — doing so cuts the gesture animation short
        // and can leave the button state out of sync with the actual overview
        // state. Let the gesture's own animation handle the transition and just
        // clean up our _fromDesktop bookkeeping.
        if (adj?.gestureInProgress || Main.overview.animationInProgress) {
            if (!checked)
                this.mainDock.dash.showAppsButton._fromDesktop = false;
            this.searchController._setSearchActive(false);
            return;
        }

        if (!Main.overview.visible) {
            this.mainDock.dash.showAppsButton._fromDesktop = true;
            Main.overview.show(OverviewControls.ControlsState.APP_GRID);
        } else if (!checked && this.mainDock.dash.showAppsButton._fromDesktop &&
            !this._inCtrlAltTabSwitcher) {
            Main.overview.hide();
            this.mainDock.dash.showAppsButton._fromDesktop = false;
        } else {
            // TODO: I'm not sure how reliable this is, we might need to move the
            // _onShowAppsButtonToggled logic into the extension.
            if (!checked)
                this.mainDock.dash.showAppsButton._fromDesktop = false;


            // Instead of "syncing" the stock button, let's call its callback directly.
            overviewControls._onShowAppsButtonToggled();
        }

        // Because we "disconnected" from the search controller, we have to manage its state.
        this.searchController._setSearchActive(false);
    }

    _overrideAppMenus() {
        this._methodInjections.add(AppMenu.AppMenu.prototype,
            '_updateFavoriteItem', function (originalFunction, ...args) {
                /* eslint-disable no-invalid-this */
                originalFunction.call(this, ...args);
                if (!this._toggleFavoriteItem.visible)
                    return;

                const {id} = this._app;
                this._toggleFavoriteItem.label.text = this._appFavorites.isFavorite(id)
                    ? _('Unpin') : __('Pin to Dock');
                /* eslint-enable no-invalid-this */
            });
    }

    destroy() {
        this.exitWiggleMode();
        this.emit('destroy');
        this._destroyCommandPalette();
        if (this._toggleLater) {
            Utils.laterRemove(this._toggleLater);
            delete this._toggleLater;
        }
        this._restoreDash();
        this._deleteDocks();
        this._revertPanelCorners();
        if (this._oldSelectorMargin)
            this.searchController.margin_bottom = this._oldSelectorMargin;
        if (this._fm1Client) {
            this._fm1Client.destroy();
            this._fm1Client = null;
        }
        this._dockProfiles?.destroy();
        this._dockProfiles = null;
        this._notificationsMonitor.destroy();
        this._screencastMonitor?.destroy();
        this._screencastMonitor = null;
        this._mprisMonitor?.destroy();
        this._mprisMonitor = null;
        this._appSpread.destroy();
        this._trash?.destroy();
        this._trash = null;
        this._pinnedCommandsManager?.destroy();
        this._pinnedCommandsManager = null;
        this._categoryIcons?.forEach(ci => ci.destroy());
        this._categoryIcons = [];
        Locations.unWrapFileManagerApp();
        this._removables?.destroy();
        this._removables = null;
        this._iconTheme = null;
        this._remoteModel?.destroy();
        this._appIconsDecorator?.destroy();
        this._volumeControl?.destroy();
        this._volumeControl = null;
        this._settings = null;
        this._appSwitcherSettings = null;
        this._oldDash = null;

        this._desktopIconsUsableArea?.destroy();
        this._desktopIconsUsableArea = null;
        this._extension = null;
        DockManager._singleton = null;
    }

    /**
     * Adjust Panel corners, remove this when 41 won't be supported anymore
     */
    _adjustPanelCorners() {
        if (!this._hasPanelCorners())
            return;

        const position = Utils.getPosition(this._preferredMonitorIndex);
        const isHorizontal = (position === St.Side.TOP) || (position === St.Side.BOTTOM);
        const dockOnPrimary  = this._settings.multiMonitor ||
                             this._preferredMonitorIndex === Main.layoutManager.primaryIndex;

        if (!isHorizontal && dockOnPrimary && this.settings.dockExtended && this.settings.dockFixed) {
            Main.panel._rightCorner.hide();
            Main.panel._leftCorner.hide();
        } else {
            this._revertPanelCorners();
        }
    }

    _revertPanelCorners() {
        if (!this._hasPanelCorners())
            return;

        Main.panel._leftCorner.show();
        Main.panel._rightCorner.show();
    }

    _hasPanelCorners() {
        return !!Main.panel?._rightCorner && !!Main.panel?._leftCorner;
    }
}
Signals.addSignalMethods(DockManager.prototype);

// This class drives long-running icon animations, to keep them running in sync
// with each other, and to save CPU by pausing them when the dock is hidden.
export class IconAnimator {
    constructor(actor) {
        this._count = 0;
        this._started = false;
        this._animations = {
            wiggle: [],
            jiggle: [],
        };
        this._signalsHandler = new Utils.GlobalSignalsHandler();
        const iconAnimDuration = DockManager.settings.iconAnimatorDuration ?? ICON_ANIMATOR_DURATION;
        this._timeline = new Clutter.Timeline({
            duration: AnimationUtils.adjustAnimationTime(iconAnimDuration) || 1,
            repeat_count: -1,
            actor,
        });

        this._updateSettings();
        this._signalsHandler.add([
            St.Settings.get(),
            'notify',
            () => this._updateSettings(),
        ], [
            this._timeline,
            'new-frame',
            () => {
                const progress = this._timeline.get_progress();
                const wiggleRotation = progress < 1 / 6 ? 15 * Math.sin(progress * 24 * Math.PI) : 0;
                const wigglers = this._animations.wiggle;
                for (let i = 0, iMax = wigglers.length; i < iMax; i++)
                    wigglers[i].target.rotation_angle_z = wiggleRotation;

                // Jiggle animation for wiggle mode — continuous gentle rotation
                const jigglers = this._animations.jiggle;
                for (let i = 0, iMax = jigglers.length; i < iMax; i++) {
                    const jiggler = jigglers[i];
                    const angle = 2.5 * Math.sin(2 * Math.PI * progress + jiggler.phaseOffset);
                    jiggler.target.rotation_angle_z = angle;
                }
            },
        ]);
    }

    _updateSettings() {
        const iconAnimDuration = DockManager.settings.iconAnimatorDuration ?? ICON_ANIMATOR_DURATION;
        this._timeline.set_duration(
            AnimationUtils.adjustAnimationTime(iconAnimDuration) || 1);
    }

    destroy() {
        this._signalsHandler.destroy();
        this._timeline.stop();
        delete this._timeline;
        for (const pairs of Object.values(this._animations)) {
            for (let i = 0, iMax = pairs.length; i < iMax; i++) {
                const pair = pairs[i];
                pair.target.disconnect(pair.targetDestroyId);
            }
        }
        this._animations = null;
    }

    pause() {
        if (this._started && this._count > 0)
            this._timeline.stop();

        this._started = false;
    }

    start() {
        if (!this._started && this._count > 0)
            this._timeline.start();

        this._started = true;
    }

    addAnimation(target, name, options = {}) {
        const targetDestroyId = target.connect('destroy',
            () => this.removeAnimation(target, name));
        const entry = {target, targetDestroyId};
        if (name === 'jiggle')
            entry.phaseOffset = options.phaseOffset ?? Math.random() * 2 * Math.PI;
        this._animations[name].push(entry);
        if (this._started && this._count === 0)
            this._timeline.start();

        this._count++;
    }

    removeAnimation(target, name) {
        const pairs = this._animations[name];
        for (let i = 0, iMax = pairs.length; i < iMax; i++) {
            const pair = pairs[i];
            if (pair.target === target) {
                target.disconnect(pair.targetDestroyId);
                pairs.splice(i, 1);
                this._count--;
                if (this._started && this._count === 0)
                    this._timeline.stop();

                return;
            }
        }
    }
}
